const MENU_ENCRYPT = "text-chiffrierer-encrypt";
const MENU_ENCRYPT_WINDOW = "text-chiffrierer-encrypt-window";
const MENU_SHOW_QR = "text-chiffrierer-show-qr";
const MENU_SHOW_AUDIO = "text-chiffrierer-show-audio";
const MENU_DECRYPT = "text-chiffrierer-decrypt";
const QR_STORAGE_KEY = "qrWindowText";
const TEXT_STORAGE_KEY = "textWindowText";
const AUDIO_STORAGE_KEY = "audioWindowText";

const CIPHER_FORMATS = new Set(["katakana", "runes", "braille", "zalgo", "mixed"]);
const DEFAULT_CIPHER_FORMAT = "katakana";

/**
 * One-shot password for a single UI action when "Remember" is off.
 * Never written to storage.local – memory only.
 */
let ephemeralPassword = null;
let ephemeralRefCount = 0;

/** contextMenus / menus: available on desktop Firefox, NOT on Firefox for Android. */
function getContextMenusApi() {
  try {
    if (typeof browser !== "undefined") {
      if (browser.contextMenus && typeof browser.contextMenus.create === "function") {
        return browser.contextMenus;
      }
      if (browser.menus && typeof browser.menus.create === "function") {
        return browser.menus;
      }
    }
  } catch (_e) {
    // API missing or restricted
  }
  return null;
}

function hasWindowsApi() {
  try {
    return Boolean(browser.windows && typeof browser.windows.create === "function");
  } catch (_e) {
    return false;
  }
}

/**
 * Sync background I18n to the stored addon language.
 * I18n.init() only runs once per service-worker life; without this re-sync,
 * context menu titles stay on the browser UI language (e.g. French) after
 * the user changes the language in the popup.
 */
async function syncBackgroundLocale() {
  await I18n.init();
  let stored = "";
  try {
    const data = await browser.storage.local.get(I18n.STORAGE_KEY);
    stored = (data && data[I18n.STORAGE_KEY]) || "";
  } catch (_e) {
    stored = "";
  }

  if (!stored || stored === "auto") {
    await I18n.setLocale("auto", { persist: false });
  } else {
    await I18n.setLocale(stored, { persist: false });
  }
}

async function setupContextMenus() {
  const menus = getContextMenusApi();
  if (!menus) {
    return;
  }

  try {
    await syncBackgroundLocale();
    await menus.removeAll();

    menus.create({
      id: MENU_ENCRYPT,
      title: I18n.t("menuEncryptDirect") || "Verschlüsseln (direkt)",
      contexts: ["selection"]
    });

    menus.create({
      id: MENU_ENCRYPT_WINDOW,
      title: I18n.t("menuEncryptWindow") || "Verschlüsseln (Fenster)",
      contexts: ["selection"]
    });

    menus.create({
      id: MENU_SHOW_QR,
      title: I18n.t("menuShowQr") || "Als QR-Code anzeigen",
      contexts: ["selection"]
    });

    menus.create({
      id: MENU_SHOW_AUDIO,
      title: I18n.t("menuShowAudio") || "Als Modem-Audio öffnen",
      contexts: ["selection"]
    });

    menus.create({
      id: MENU_DECRYPT,
      title: I18n.t("menuDecryptSelection") || "Auswahl entschlüsseln",
      contexts: ["selection"]
    });
  } catch (error) {
    console.warn("Enigma: context menus unavailable", error);
  }
}

browser.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes[I18n.STORAGE_KEY]) {
    // Locale changed in popup/options — rebuild menu titles in that language
    setupContextMenus().catch(() => {});
  }
});

/** Password from session storage only – never storage.local. */
async function getSessionPassword() {
  try {
    if (browser.storage && browser.storage.session) {
      const data = await browser.storage.session.get("password");
      if (data && data.password) {
        return data.password;
      }
    }
  } catch (_e) {}
  return "";
}

/**
 * Resolve password for crypto:
 * 1) explicit argument (one message)
 * 2) in-memory ephemeral (active UI action without "Remember")
 * 3) session storage (Remember / auto-decrypt)
 */
async function resolvePassword(explicit) {
  if (typeof explicit === "string" && explicit.length > 0) {
    return explicit;
  }
  if (ephemeralPassword) {
    return ephemeralPassword;
  }
  return getSessionPassword();
}

async function hasAnyPassword(explicit) {
  const pw = await resolvePassword(explicit);
  return Boolean(pw);
}

async function getPreferredCipherFormat() {
  try {
    const data = await browser.storage.local.get("cipherFormat");
    const fmt = data && data.cipherFormat;
    if (fmt && CIPHER_FORMATS.has(fmt)) {
      return fmt;
    }
  } catch (_e) {}
  return DEFAULT_CIPHER_FORMAT;
}

/**
 * Persist password only in session when remember=true.
 * When remember=false, keep it in memory for the duration of an action (ref-counted).
 */
async function beginPasswordScope(password, remember) {
  const pw = (password || "").trim();
  if (!pw) {
    return { usedEphemeral: false };
  }

  if (remember) {
    try {
      await browser.storage.session.set({ password: pw, remember: true });
    } catch (error) {
      console.warn("Enigma: could not write session password", error);
    }
    return { usedEphemeral: false };
  }

  ephemeralPassword = pw;
  ephemeralRefCount += 1;
  return { usedEphemeral: true };
}

function endPasswordScope(scope) {
  if (!scope || !scope.usedEphemeral) {
    return;
  }
  ephemeralRefCount = Math.max(0, ephemeralRefCount - 1);
  if (ephemeralRefCount === 0) {
    ephemeralPassword = null;
  }
}

/** Remove legacy plaintext passwords from local storage (migration). */
async function purgeLocalPassword() {
  try {
    await browser.storage.local.remove("password");
  } catch (_e) {}
}

async function notifyMissingPassword() {
  await I18n.init();

  try {
    await browser.notifications.create("enigma-missing-password", {
      type: "basic",
      title: I18n.t("extName"),
      message: I18n.t("notifyMissingPassword")
    });
  } catch (_error) {
    // Notifications unavailable (common on Android).
  }
}

async function notifyError(message) {
  await I18n.init().catch(() => {});
  try {
    await browser.notifications.create("enigma-action-error", {
      type: "basic",
      title: (typeof I18n.t === "function" ? I18n.t("extName") : null) || "Enigma 2.0",
      message: message || "Aktion fehlgeschlagen."
    });
  } catch (_error) {
    // Notifications unavailable.
  }
}

/**
 * Open an extension page. Desktop: popup window. Android: new tab (windows API missing).
 */
async function openPopupWindow(page, storageKey, text, size) {
  const payload = (text || "").trim();
  if (!payload) {
    await I18n.init().catch(() => {});
    await notifyError(I18n.t("errSelectTextFirst") || "Bitte zuerst Text markieren.");
    return;
  }

  try {
    await browser.storage.session.set({ [storageKey]: payload });
  } catch (_error) {
    console.warn("Could not write window payload to session storage", _error);
  }

  let windowUrl = browser.runtime.getURL(page);
  try {
    if (payload.length <= 1800) {
      windowUrl += "#t=" + encodeURIComponent(payload);
    }
  } catch (_error) {
    // ignore
  }

  const width = (size && size.width) || 320;
  const height = (size && size.height) || 360;

  if (hasWindowsApi()) {
    try {
      await browser.windows.create({
        url: windowUrl,
        type: "popup",
        width,
        height,
        left: 80,
        top: 80
      });
      return;
    } catch (_error) {
      try {
        await browser.windows.create({
          url: windowUrl,
          type: "popup",
          width,
          height
        });
        return;
      } catch (_retryError) {
        // fall through to tabs
      }
    }
  }

  try {
    await browser.tabs.create({ url: windowUrl });
  } catch (tabError) {
    const msg = (tabError && tabError.message) || String(tabError);
    await notifyError("Seite konnte nicht geöffnet werden: " + msg);
  }
}

async function openTextWindow(text) {
  await openPopupWindow("text-window.html", TEXT_STORAGE_KEY, text, {
    width: 280,
    height: 340
  });
}

async function openQrWindow(text) {
  await openPopupWindow("qr-window.html", QR_STORAGE_KEY, text, {
    width: 340,
    height: 500
  });
}

async function openAudioWindow(text) {
  await openPopupWindow("audio-window.html", AUDIO_STORAGE_KEY, text, {
    width: 360,
    height: 480
  });
}

async function ensureContentScript(tabId) {
  try {
    await browser.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ["lib/i18n.js", "lib/crypto.js", "content/content.js"]
    });
  } catch (e) {
    console.warn("Script injection attempt failed", e);
  }
}

async function sendTabAction(tabId, action, selectedText = "") {
  // Password never sent to content scripts.
  const message = { action, selectedText: selectedText || "" };
  try {
    return await browser.tabs.sendMessage(tabId, message);
  } catch (_error) {
    await ensureContentScript(tabId);
    return await browser.tabs.sendMessage(tabId, message);
  }
}

async function runOnTab(action, preferredTabId, selectedText = "") {
  if (!(await hasAnyPassword())) {
    await notifyMissingPassword();
    return;
  }

  let tabId = preferredTabId;
  if (!tabId) {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
  }
  if (!tabId) {
    return;
  }

  try {
    const response = await sendTabAction(tabId, action, selectedText);
    if (response && !response.ok) {
      await notifyError(
        response.error ||
          "Aktion fehlgeschlagen. Versuche es über das Popup oder markiere den Text erneut."
      );
    }
  } catch (retryError) {
    const msg = (retryError && retryError.message) || String(retryError);
    await notifyError(
      "Content Script konnte nicht geladen werden. Lade die Seite komplett neu und versuche es erneut. " +
        msg
    );
  }
}

async function handleEncryptToWindow(selectedText, targetTabId) {
  if (!(await hasAnyPassword())) {
    await notifyMissingPassword();
    return;
  }

  const text = (selectedText || "").trim();

  // Prefer encrypting in background when context menu already has the text.
  if (text) {
    try {
      if (typeof TextCrypto !== "undefined" && TextCrypto.isEncrypted(text)) {
        await notifyError(
          (typeof I18n !== "undefined" && I18n.t("errAlreadyEncrypted")) ||
            "Text ist bereits verschlüsselt."
        );
        return;
      }
      const password = await resolvePassword();
      const format = await getPreferredCipherFormat();
      const encrypted = await TextCrypto.encrypt(text, password, format);
      await openTextWindow(encrypted);
      return;
    } catch (error) {
      const msg = (error && error.message) || String(error);
      await notifyError("Konnte nicht verschlüsseln: " + msg);
      return;
    }
  }

  let tabId = targetTabId;
  if (!tabId) {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
  }
  if (!tabId) return;

  try {
    const response = await sendTabAction(tabId, "encrypt-window", selectedText);
    if (!response || !response.ok || !response.encrypted) {
      throw new Error(response?.error || "Verschlüsselung fehlgeschlagen");
    }
    await openTextWindow(response.encrypted);
  } catch (error) {
    const msg = (error && error.message) || String(error);
    await notifyError("Konnte nicht verschlüsseln: " + msg);
  }
}

async function handleShowQr(selectedText) {
  const text = (selectedText || "").trim();
  if (!text) {
    await I18n.init().catch(() => {});
    await notifyError(I18n.t("errSelectTextFirst") || "Bitte zuerst Text markieren.");
    return;
  }
  await openQrWindow(text);
}

async function handleShowAudio(selectedText) {
  const text = (selectedText || "").trim();
  if (!text) {
    await I18n.init().catch(() => {});
    await notifyError(I18n.t("errSelectTextFirst") || "Bitte zuerst Text markieren.");
    return;
  }
  await openAudioWindow(text);
}

/* ── Crypto API (background only) ── */

async function handleCryptoEncrypt(message) {
  const plaintext = message && message.plaintext != null ? String(message.plaintext) : "";
  if (!plaintext) {
    return { ok: false, error: "Kein Klartext." };
  }

  const password = await resolvePassword(message.password);
  if (!password) {
    return { ok: false, error: "Passwort fehlt. Bitte im Popup eingeben." };
  }

  let format = message.format;
  if (!format || !CIPHER_FORMATS.has(format)) {
    format = await getPreferredCipherFormat();
  }

  try {
    const encrypted = await TextCrypto.encrypt(plaintext, password, format);
    return { ok: true, encrypted };
  } catch (error) {
    return { ok: false, error: (error && error.message) || "Verschlüsselung fehlgeschlagen." };
  }
}

async function handleCryptoDecrypt(message) {
  const ciphertext =
    message && message.ciphertext != null ? String(message.ciphertext) : "";
  if (!ciphertext) {
    return { ok: false, error: "Kein Cipher." };
  }

  const password = await resolvePassword(message.password);
  if (!password) {
    return { ok: false, error: "Passwort fehlt. Bitte im Popup eingeben." };
  }

  try {
    const plaintext = await TextCrypto.decrypt(ciphertext, password);
    return { ok: true, plaintext };
  } catch (error) {
    return {
      ok: false,
      error: (error && error.message) || "Entschlüsselung fehlgeschlagen."
    };
  }
}

async function handleCryptoDecryptMany(message) {
  const ciphers = message && Array.isArray(message.ciphers) ? message.ciphers : [];
  const password = await resolvePassword(message.password);
  if (!password) {
    return {
      ok: false,
      error: "Passwort fehlt. Bitte im Popup eingeben.",
      results: ciphers.map(() => ({ ok: false }))
    };
  }

  const results = [];
  for (const cipher of ciphers) {
    try {
      const plaintext = await TextCrypto.decrypt(String(cipher || ""), password);
      results.push({ ok: true, plaintext });
    } catch (_error) {
      results.push({ ok: false });
    }
  }
  return { ok: true, results };
}

async function handleCryptoStatus() {
  return {
    ok: true,
    hasPassword: await hasAnyPassword()
  };
}

/**
 * Popup / ui.html: run a content action with password scoped correctly.
 * Password is never forwarded to the tab.
 */
async function handleRunContentAction(message) {
  const action = message && message.action;
  if (!action) {
    return { ok: false, error: "Keine Aktion." };
  }

  const password = (message.password || "").trim();
  const remember = Boolean(message.remember);
  let tabId = message.tabId;

  if (!password && !(await hasAnyPassword())) {
    return { ok: false, error: "Bitte Passwort eingeben." };
  }

  if (!tabId) {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
  }
  if (!tabId) {
    return { ok: false, error: "Kein aktiver Tab." };
  }

  const scope = await beginPasswordScope(password, remember);
  try {
    const response = await sendTabAction(tabId, action, message.selectedText || "");
    if (!response) {
      return { ok: false, error: "Keine Antwort vom Content-Script." };
    }
    return response;
  } catch (error) {
    const msg = (error && error.message) || String(error);
    if (msg.includes("Receiving end") || msg.includes("Could not establish")) {
      return {
        ok: false,
        error:
          "Content Script fehlt. Seite neu laden, dann erneut versuchen."
      };
    }
    return { ok: false, error: msg };
  } finally {
    endPasswordScope(scope);
  }
}

/**
 * Persist or clear session password (popup/ui). Never uses local storage.
 */
async function handleSetSessionPassword(message) {
  const password = (message.password || "").trim();
  const remember = Boolean(message.remember);

  try {
    if (remember && password) {
      await browser.storage.session.set({ password, remember: true });
      return { ok: true };
    }
    await browser.storage.session.remove(["password", "remember"]);
    if (!remember) {
      ephemeralPassword = null;
      ephemeralRefCount = 0;
    }
    return { ok: true };
  } catch (error) {
    return { ok: false, error: (error && error.message) || "Session-Storage fehlgeschlagen." };
  }
}

browser.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message !== "object") {
    return false;
  }

  const type = message.type;
  if (!type) {
    return false;
  }

  const run = async () => {
    switch (type) {
      case "crypto-encrypt":
        return handleCryptoEncrypt(message);
      case "crypto-decrypt":
        return handleCryptoDecrypt(message);
      case "crypto-decrypt-many":
        return handleCryptoDecryptMany(message);
      case "crypto-status":
        return handleCryptoStatus();
      case "run-content-action":
        return handleRunContentAction(message);
      case "set-session-password":
        return handleSetSessionPassword(message);
      default:
        return { ok: false, error: "Unbekannter Nachrichtentyp." };
    }
  };

  run()
    .then((result) => sendResponse(result))
    .catch((error) =>
      sendResponse({
        ok: false,
        error: (error && error.message) || String(error)
      })
    );
  return true;
});

const menusApi = getContextMenusApi();
if (menusApi && menusApi.onClicked) {
  menusApi.onClicked.addListener((info, tab) => {
    const selectedText = info.selectionText || "";
    const targetTabId = tab?.id;

    if (info.menuItemId === MENU_ENCRYPT) {
      runOnTab("encrypt-selection", targetTabId, selectedText);
    }

    if (info.menuItemId === MENU_ENCRYPT_WINDOW) {
      handleEncryptToWindow(selectedText, targetTabId);
    }

    if (info.menuItemId === MENU_SHOW_QR) {
      handleShowQr(selectedText);
    }

    if (info.menuItemId === MENU_SHOW_AUDIO) {
      handleShowAudio(selectedText);
    }

    if (info.menuItemId === MENU_DECRYPT) {
      runOnTab("decrypt-selection", targetTabId, selectedText);
    }
  });
}

let androidClickHooked = false;

function getUiUrl() {
  return browser.runtime.getURL("ui.html");
}

async function openUiInTab() {
  const url = getUiUrl();

  try {
    const existing = await browser.tabs.query({}).catch(() => []);
    const match = (existing || []).find(
      (t) => t.url && t.url.indexOf("ui.html") !== -1 && t.url.indexOf("moz-extension://") === 0
    );
    if (match && match.id != null) {
      await browser.tabs.update(match.id, { active: true });
      return;
    }
    await browser.tabs.create({ url });
    return;
  } catch (error) {
    console.warn("Enigma: tabs.create UI failed", error);
  }

  try {
    if (browser.runtime.openOptionsPage) {
      await browser.runtime.openOptionsPage();
    }
  } catch (_e) {
    // last resort already failed
  }
}

async function setupAndroidActionUiAndClick() {
  try {
    const platform = await browser.runtime.getPlatformInfo();
    if (!platform || platform.os !== "android") {
      return;
    }

    if (browser.action && typeof browser.action.setPopup === "function") {
      await browser.action.setPopup({ popup: "" });
    }

    if (!androidClickHooked && browser.action && browser.action.onClicked) {
      browser.action.onClicked.addListener(() => {
        openUiInTab().catch(() => {});
      });
      androidClickHooked = true;
    }
  } catch (error) {
    console.warn("Enigma: Android action setup failed", error);
  }
}

purgeLocalPassword().catch(() => {});
setupContextMenus().catch(() => {});
setupAndroidActionUiAndClick().catch(() => {});

browser.runtime.onInstalled.addListener((details) => {
  purgeLocalPassword().catch(() => {});
  setupContextMenus().catch(() => {});
  setupAndroidActionUiAndClick()
    .then(async () => {
      try {
        const platform = await browser.runtime.getPlatformInfo();
        if (platform && platform.os === "android") {
          if (details.reason === "install" || details.reason === "update") {
            await openUiInTab();
          }
        }
      } catch (_e) {}
    })
    .catch(() => {});
});

browser.runtime.onStartup.addListener(() => {
  purgeLocalPassword().catch(() => {});
  setupAndroidActionUiAndClick().catch(() => {});
});
