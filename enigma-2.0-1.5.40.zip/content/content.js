const SKIP_TAGS = new Set([
  "SCRIPT",
  "STYLE",
  "NOSCRIPT",
  "TEXTAREA",
  "INPUT",
  "SELECT",
  "OPTION",
  "CODE",
  "PRE"
]);

const MATRIX_ATTR = "data-text-chiffrierer";
const MATRIX_SELECTOR = `[${MATRIX_ATTR}="true"]`;
const PROCESSED_ATTR = "data-text-chiffrierer-processed";
const DECRYPTED_ATTR = "data-text-chiffrierer-decrypted";
const TEMP_MARKER_ATTR = "data-enigma-temp";

let extensionUpdateDepth = 0;
let extensionIsUpdating = false;
let currentMatrixColor = "#00ff41";
let currentMatrixShadow = "0 0 5px rgba(0, 255, 65, 0.45), 0 0 12px rgba(0, 255, 65, 0.2)";

const MATRIX_COLORS = {
  "#00ff41": "0 0 5px rgba(0, 255, 65, 0.45), 0 0 12px rgba(0, 255, 65, 0.2)",
  "#ffffff": "0 0 6px rgba(0, 0, 0, 0.6)",
  "#00bfff": "0 0 5px rgba(0, 191, 255, 0.5), 0 0 12px rgba(0, 191, 255, 0.25)",
  "#000000": "0 0 4px rgba(255, 255, 255, 0.8)"
};

const TEXT_CONTAINER_SELECTORS = [
  '[data-testid="tweetText"]',
  '[data-testid="tweet"] div[lang]',
  "article div[lang][dir]",
  '[contenteditable="true"][role="textbox"]',
  '[contenteditable="true"][data-testid]',
  'div[data-testid^="tweetTextarea"]'
].join(", ");

const CIPHER_FORMATS = new Set(["katakana", "runes", "braille", "zalgo", "mixed"]);
const DEFAULT_CIPHER_FORMAT = "katakana";

/** Load EnigmaRain so Matrix cipher spans render as alien stencil glyphs. */
let enigmaRainFontPromise = null;
function ensureEnigmaRainFont() {
  if (enigmaRainFontPromise) {
    return enigmaRainFontPromise;
  }
  enigmaRainFontPromise = (async () => {
    try {
      if (typeof FontFace === "undefined" || !browser?.runtime?.getURL) {
        return false;
      }
      if (document.fonts && document.fonts.check('12px "EnigmaRain"')) {
        return true;
      }
      const url = browser.runtime.getURL("fonts/EnigmaRain.ttf");
      const face = new FontFace("EnigmaRain", `url("${url}")`);
      await face.load();
      document.fonts.add(face);
      return true;
    } catch (_e) {
      return false;
    }
  })();
  return enigmaRainFontPromise;
}

// Font is loaded lazily on first matrix span (see createMatrixSpan) — not on every page.

async function getPreferredCipherFormat() {
  try {
    const data = await browser.storage.local.get("cipherFormat");
    const fmt = data && data.cipherFormat;
    if (fmt && CIPHER_FORMATS.has(fmt)) {
      return fmt;
    }
  } catch (_error) {
    // storage unavailable
  }
  return DEFAULT_CIPHER_FORMAT;
}

/**
 * Crypto runs only in the background. Content scripts never receive the password.
 */
async function bgCryptoEncrypt(plaintext, format) {
  const response = await browser.runtime.sendMessage({
    type: "crypto-encrypt",
    plaintext,
    format: format || undefined
  });
  if (!response || !response.ok || !response.encrypted) {
    throw new Error(
      (response && response.error) || I18n.t("errUnknown") || "Verschlüsselung fehlgeschlagen."
    );
  }
  return response.encrypted;
}

async function bgCryptoDecrypt(ciphertext) {
  const response = await browser.runtime.sendMessage({
    type: "crypto-decrypt",
    ciphertext
  });
  if (!response || !response.ok || response.plaintext == null) {
    throw new Error(
      (response && response.error) || I18n.t("errDecryptFailed") || "Entschlüsselung fehlgeschlagen."
    );
  }
  return response.plaintext;
}

async function bgCryptoDecryptMany(ciphers) {
  if (!ciphers || ciphers.length === 0) {
    return [];
  }
  try {
    const response = await browser.runtime.sendMessage({
      type: "crypto-decrypt-many",
      ciphers
    });
    // Soft-fail when password missing or wrong: empty ok flags (auto-decrypt must not throw)
    if (response && Array.isArray(response.results)) {
      return response.results;
    }
  } catch (_e) {
    // background unavailable
  }
  return ciphers.map(() => ({ ok: false }));
}

async function bgHasPassword() {
  try {
    const status = await browser.runtime.sendMessage({ type: "crypto-status" });
    return Boolean(status && status.hasPassword);
  } catch (_e) {
    return false;
  }
}

async function encryptWithPreferredFormat(plaintext) {
  const format = await getPreferredCipherFormat();
  return bgCryptoEncrypt(plaintext, format);
}

// Capture the exact selection range + text at the moment the user opens the context menu.
// This is the most reliable way to preserve selection on SPAs like X.com,
// because the live window.getSelection() is often cleared by the time the
// async context menu click message arrives from the background script.
let lastContextMenuRange = null;
let lastContextMenuText = null;

document.addEventListener('contextmenu', () => {
  const sel = window.getSelection();
  if (sel && sel.rangeCount > 0) {
    try {
      lastContextMenuRange = sel.getRangeAt(0).cloneRange();
      lastContextMenuText = sel.toString();
    } catch (_) {
      lastContextMenuRange = null;
      lastContextMenuText = null;
    }
  }
}, true);

// Register the runtime message listener as early as possible in script execution.
// This ensures that even if later initialization code has problems on heavy SPAs
// like X.com, the receiving end for sendMessage from background/popup exists.
browser.runtime.onMessage.addListener(onRuntimeMessage);

function detectCipherFormatFromText(text) {
  if (typeof text !== "string") return "katakana";
  // Prefer crypto engine (knows 3nigm4 / pads / recovery)
  if (typeof TextCrypto !== "undefined" && typeof TextCrypto.peekFormatId === "function") {
    try {
      const id = TextCrypto.peekFormatId(text);
      if (id && CIPHER_FORMATS.has(id)) {
        return id;
      }
    } catch (_e) {}
  }
  // Legacy tagged formats
  if (text.includes("⎔MXD:")) return "mixed";
  if (text.includes("⎔ZL2:")) return "zalgo";
  if (text.includes("⎔RN2:")) return "runes";
  if (text.includes("⎔BR2:")) return "braille";
  if (text.includes("⎔MX2:") || text.includes("ENC:v1:")) return "katakana";
  // Bare (prefix-free) payloads – detect by character set
  const hasRunes = /[\u16A0-\u16FF]/.test(text);
  const hasBraille = /[\u2800-\u28FF]/.test(text);
  const hasZalgo = /\p{M}/u.test(text) && /[A-Za-z0-9+/=]/.test(text);
  const hasFullwidth =
    /[\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF0B\uFF0F\uFF1D]/.test(text);
  // Glitch lane (IPA / exotic letters)
  const hasGlitch = /[ȺȾȽɃɄɅɆɈɊɌɎɐ-ʄʔ]/.test(text);
  const hasMatrix = /[\uFF66-\uFF9D]/.test(text);
  const styleCount = [
    hasRunes,
    hasBraille,
    hasZalgo,
    hasFullwidth,
    hasGlitch,
    hasMatrix
  ].filter(Boolean).length;
  if (styleCount >= 2) return "mixed";
  if (hasZalgo) return "zalgo";
  if (hasRunes) return "runes";
  if (hasBraille) return "braille";
  return "katakana";
}

function applyMatrixSpanStyles(span, encryptedText) {
  const text = encryptedText != null ? encryptedText : (span.textContent || "");
  const format =
    span.getAttribute("data-cipher-format") || detectCipherFormatFromText(text);
  span.setAttribute("data-cipher-format", format);

  const color = currentMatrixColor || "#00ff41";
  const shadow = MATRIX_COLORS[color] || MATRIX_COLORS["#00ff41"];
  span.setAttribute("data-matrix-color", color);
  span.style.setProperty("word-break", "break-all", "important");
  span.style.setProperty("overflow-wrap", "anywhere", "important");
  span.style.setProperty("max-width", "100%", "important");

  // Same solid color as other formats (user-chosen matrix color)
  span.style.setProperty("color", color, "important");
  span.style.setProperty("-webkit-text-fill-color", color, "important");
  span.style.setProperty("caret-color", color, "important");

  // Zalgo: no glow, hard containment so marks stay in the post box
  if (format === "zalgo") {
    span.style.setProperty("text-shadow", "none", "important");
    span.style.setProperty("display", "inline-block", "important");
    span.style.setProperty("overflow", "hidden", "important");
    span.style.setProperty("line-height", "1.45", "important");
    span.style.setProperty("white-space", "pre-wrap", "important");
    span.style.setProperty("vertical-align", "baseline", "important");
    span.style.removeProperty("font-family");
  } else if (format === "katakana" || format === "mixed") {
    // Matrix / 3nigm4: optional rain font + glow in chosen color
    span.style.setProperty("text-shadow", shadow, "important");
    span.style.setProperty(
      "font-family",
      format === "mixed"
        ? '"EnigmaRain", "Segoe UI Symbol", "MS Gothic", "Consolas", monospace'
        : '"EnigmaRain", "Consolas", "Courier New", monospace',
      "important"
    );
    span.style.setProperty("letter-spacing", "0.04em", "important");
    span.style.setProperty("line-height", format === "mixed" ? "1.35" : "1.15", "important");
    span.style.setProperty("font-weight", "normal", "important");
    if (format === "mixed") {
      span.style.setProperty("display", "inline-block", "important");
      span.style.setProperty("max-width", "100%", "important");
      span.style.setProperty("overflow-wrap", "anywhere", "important");
    }
  } else {
    span.style.setProperty("text-shadow", shadow, "important");
    span.style.removeProperty("font-family");
  }
}

function createMatrixSpan(encryptedText, formatHint) {
  const span = document.createElement("span");
  span.setAttribute(MATRIX_ATTR, "true");
  span.textContent = encryptedText;
  // Prefer explicit format from encrypt / findTokens (survives until reload)
  if (formatHint && CIPHER_FORMATS.has(formatHint)) {
    span.setAttribute("data-cipher-format", formatHint);
  }
  applyMatrixSpanStyles(span, encryptedText);
  // Font is optional polish; rain unicode already looks Matrix without it
  ensureEnigmaRainFont().then((ok) => {
    if (ok && span.isConnected) {
      applyMatrixSpanStyles(span, encryptedText);
    }
  });
  return span;
}

function contentFingerprint(text) {
  if (!text) {
    return "";
  }

  return `${text.length}:${text.slice(0, 24)}:${text.slice(-12)}`;
}

function markProcessed(element, text) {
  element.setAttribute(PROCESSED_ATTR, contentFingerprint(text));
  element.removeAttribute(DECRYPTED_ATTR);
}

function markDecrypted(element) {
  element.setAttribute(DECRYPTED_ATTR, "true");
  element.removeAttribute(PROCESSED_ATTR);
}

function cleanupDecryptedContent(root) {
  if (!root) return;

  // Remove our tracking attributes from containers that no longer have cipher content
  const marked = root.querySelectorAll(`[${DECRYPTED_ATTR}], [${PROCESSED_ATTR}]`);
  marked.forEach(el => {
    if (!el.closest(MATRIX_SELECTOR) && !el.hasAttribute(MATRIX_ATTR)) {
      el.removeAttribute(DECRYPTED_ATTR);
      el.removeAttribute(PROCESSED_ATTR);
    }
  });

  // Merge adjacent text nodes (helps X's composer)
  try {
    root.normalize();
  } catch (_) {}
}

function isAlreadyDecrypted(element) {
  return element.getAttribute(DECRYPTED_ATTR) === "true";
}

function isExtensionNode(node) {
  if (!node) {
    return false;
  }

  if (node.nodeType === Node.ELEMENT_NODE) {
    return (
      node.getAttribute?.(MATRIX_ATTR) === "true" ||
      node.hasAttribute?.(TEMP_MARKER_ATTR) ||
      node.hasAttribute?.(PROCESSED_ATTR) ||
      node.hasAttribute?.(DECRYPTED_ATTR) ||
      Boolean(node.closest?.(MATRIX_SELECTOR))
    );
  }

  if (node.nodeType === Node.TEXT_NODE) {
    return Boolean(node.parentElement?.closest(`[${PROCESSED_ATTR}], [${DECRYPTED_ATTR}], [${TEMP_MARKER_ATTR}], ${MATRIX_SELECTOR}`));
  }

  return false;
}

async function withExtensionUpdate(callback) {
  extensionUpdateDepth += 1;
  extensionIsUpdating = true;

  try {
    return await callback();
  } finally {
    extensionUpdateDepth -= 1;

    if (extensionUpdateDepth === 0) {
      requestAnimationFrame(() => {
        if (extensionUpdateDepth === 0) {
          extensionIsUpdating = false;
        }
      });
    }
  }
}

function getSelectedText() {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) {
    return "";
  }
  return selection.toString();
}

function getContentEditableRoot(node) {
  if (!node) {
    return null;
  }

  const element = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
  return element?.closest?.('[contenteditable="true"]') || null;
}

function notifyContentEditableInput(editable, text) {
  editable.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      inputType: "insertText",
      data: text
    })
  );

  // Extra events that some editors (esp. X.com) listen to
  try {
    editable.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertText", data: text }));
    editable.dispatchEvent(new Event("change", { bubbles: true }));
  } catch (_) {}
}

function getActiveEditable() {
  const active = document.activeElement;
  if (active) {
    const root = getContentEditableRoot(active);
    if (root) return root;
  }

  // X.com / Twitter composer specific fallbacks + generic
  return (
    document.querySelector('[contenteditable="true"][role="textbox"]') ||
    document.querySelector('[contenteditable="true"][data-testid]') ||
    document.querySelector('div[data-testid^="tweetTextarea"]') ||
    document.querySelector('[contenteditable="true"]') ||
    null
  );
}

/**
 * Tries to locate the exact searchText inside an editable element
 * (handles text split across spans, common on X) and selects it.
 */
function selectTextInEditable(editable, searchText) {
  if (!editable || !searchText) return false;

  const walker = document.createTreeWalker(editable, NodeFilter.SHOW_TEXT, null);
  const textNodes = [];
  const lengths = [];
  let fullText = "";

  let node;
  while ((node = walker.nextNode())) {
    const val = node.nodeValue || "";
    textNodes.push(node);
    lengths.push(val.length);
    fullText += val;
  }

  // Try exact match first
  let startIdx = fullText.indexOf(searchText);
  let matchLength = searchText.length;

  if (startIdx === -1) {
    // Try with collapsed whitespace for X composer (text is often normalized)
    const normSearch = searchText.replace(/\s+/g, " ").trim();
    const normFull = fullText.replace(/\s+/g, " ");
    const normStart = normFull.indexOf(normSearch);
    if (normStart !== -1) {
      // Map back to original fullText position approximately
      // Find the start by searching for a prefix
      const prefix = normSearch.slice(0, 10);
      const approxStart = fullText.toLowerCase().indexOf(prefix.toLowerCase());
      if (approxStart !== -1) {
        startIdx = approxStart;
        matchLength = searchText.length;  // approximate
      }
    }
  }

  if (startIdx === -1) return false;

  const endIdx = startIdx + matchLength;

  let pos = 0;
  let startNode = null, startOffset = 0;
  let endNode = null, endOffset = 0;

  for (let i = 0; i < textNodes.length; i++) {
    const len = lengths[i];
    if (startNode === null && pos + len > startIdx) {
      startNode = textNodes[i];
      startOffset = startIdx - pos;
    }
    if (endNode === null && pos + len >= endIdx) {
      endNode = textNodes[i];
      endOffset = endIdx - pos;
      break;
    }
    pos += len;
  }

  if (!startNode || !endNode) return false;

  try {
    const range = document.createRange();
    range.setStart(startNode, Math.max(0, Math.min(startOffset, startNode.nodeValue.length)));
    range.setEnd(endNode, Math.min(endOffset, endNode.nodeValue.length));

    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Restores the exact Range that was captured when the user right-clicked.
 * This is preferred over re-searching text because it preserves the
 * original selection nodes and offsets perfectly.
 */
function restoreCapturedContextMenuRange() {
  if (!lastContextMenuRange) {
    return false;
  }
  try {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(lastContextMenuRange);
    // Keep it for a short time in case of re-entrancy; clear after successful use in caller
    return true;
  } catch (_) {
    lastContextMenuRange = null;
    return false;
  }
}

/**
 * Finds the plain searchText inside the editable by walking text nodes
 * and replaces that occurrence with a temp marker span (zero-width).
 * Returns the inserted marker element on success (or null).
 * This is more reliable than range-based delete on sites like X
 * where live ranges can be stale after context menu.
 */
async function findEditableContainingText(searchText, timeoutMs = 1500) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const candidates = document.querySelectorAll('[contenteditable="true"]');
    for (const cand of candidates) {
      if (cand.textContent && cand.textContent.includes(searchText)) {
        return cand;
      }
    }
    await new Promise(r => setTimeout(r, 25));
  }
  return null;
}

function insertTempMarkerByTextSearch(editable, searchText) {
  if (!editable || !searchText) return null;

  // Normalize for matching (X often has extra spaces, zero-width, or split text)
  const normSearch = searchText.replace(/[\s\u200B-\u200D\uFEFF]+/g, ' ').trim();

  const walker = document.createTreeWalker(editable, NodeFilter.SHOW_TEXT, null);
  const nodes = [];
  let full = '';

  let node;
  while ((node = walker.nextNode())) {
    nodes.push(node);
    full += (node.nodeValue || '');
  }

  const normFull = full.replace(/[\s\u200B-\u200D\uFEFF]+/g, ' ');
  let idx = normFull.indexOf(normSearch);
  if (idx === -1) return null;

  // Map normalized index back to original full string position (approximate but good enough)
  // Find actual position by walking original
  let origPos = 0;
  let normPos = 0;
  let actualStartIdx = -1;

  for (let i = 0; i < full.length && normPos <= idx; i++) {
    const ch = full[i];
    if (!/[\s\u200B-\u200D\uFEFF]/.test(ch)) {
      if (normPos === idx) {
        actualStartIdx = origPos;
        break;
      }
      normPos++;
    }
    origPos++;
  }

  if (actualStartIdx === -1) actualStartIdx = idx; // fallback

  // Now find the node at actualStartIdx in original
  let pos = 0;
  let startNode = null, startOff = 0;
  for (const n of nodes) {
    const len = (n.nodeValue || '').length;
    if (pos + len > actualStartIdx) {
      startNode = n;
      startOff = actualStartIdx - pos;
      break;
    }
    pos += len;
  }

  if (!startNode) return null;

  const parent = startNode.parentNode;
  if (!parent) return null;

  const nodeVal = startNode.nodeValue || '';
  const beforeText = nodeVal.substring(0, startOff);

  // Calculate how much of searchText is in this node
  const remainingInNode = nodeVal.length - startOff;
  let consumed = Math.min(remainingInNode, normSearch.length); // approx

  startNode.nodeValue = beforeText;

  // Remove remaining characters from following text nodes
  let stillToRemove = normSearch.length - consumed;
  let current = startNode.nextSibling;

  while (stillToRemove > 0 && current) {
    if (current.nodeType === Node.TEXT_NODE) {
      const v = current.nodeValue || '';
      const cleanV = v.replace(/[\s\u200B-\u200D\uFEFF]+/g, ' ');
      if (cleanV.length <= stillToRemove) {
        stillToRemove -= cleanV.length;
        const toDel = current;
        current = current.nextSibling;
        parent.removeChild(toDel);
      } else {
        // Truncate this node
        const keepLen = v.length - stillToRemove; // rough
        current.nodeValue = v.substring(0, Math.max(0, keepLen));
        stillToRemove = 0;
      }
    } else {
      current = current.nextSibling;
    }
  }

  const marker = document.createElement('span');
  marker.setAttribute(TEMP_MARKER_ATTR, 'true');
  marker.textContent = '\u200B';
  parent.insertBefore(marker, startNode.nextSibling || null);

  return marker;
}

function replaceSelection(newText, { encrypted = false } = {}) {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) {
    return false;
  }

  const range = selection.getRangeAt(0);
  const editable = getContentEditableRoot(range.commonAncestorContainer);

  if (editable) {
    range.deleteContents();

    const node = encrypted ? createMatrixSpan(newText) : document.createTextNode(newText);
    range.insertNode(node);

    selection.removeAllRanges();
    const newRange = document.createRange();
    newRange.selectNodeContents(node);
    selection.addRange(newRange);
    notifyContentEditableInput(editable, newText);
    return true;
  }

  range.deleteContents();

  const node = encrypted ? createMatrixSpan(newText) : document.createTextNode(newText);
  range.insertNode(node);

  selection.removeAllRanges();
  const newRange = document.createRange();
  newRange.selectNodeContents(node);
  selection.addRange(newRange);

  return true;
}

function collectTextNodes(root) {
  const nodes = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent) {
        return NodeFilter.FILTER_REJECT;
      }

      if (SKIP_TAGS.has(parent.tagName)) {
        return NodeFilter.FILTER_REJECT;
      }

      if (parent.closest(MATRIX_SELECTOR)) {
        return NodeFilter.FILTER_REJECT;
      }

      const value = node.nodeValue;
      if (!value || !value.trim()) {
        return NodeFilter.FILTER_REJECT;
      }

      return NodeFilter.FILTER_ACCEPT;
    }
  });

  let current = walker.nextNode();
  while (current) {
    nodes.push(current);
    current = walker.nextNode();
  }

  return nodes;
}

function wrapEncryptedTokensInNode(node) {
  const text = node.nodeValue;
  const tokens = TextCrypto.findTokens(text);
  if (tokens.length === 0) {
    return false;
  }

  const parent = node.parentNode;
  if (!parent) {
    return false;
  }

  let lastIndex = 0;

  for (const token of tokens) {
    if (token.start > lastIndex) {
      parent.insertBefore(document.createTextNode(text.slice(lastIndex, token.start)), node);
    }

    // Always display the original text slice (token.cipher is already original)
    const display = text.slice(token.start, token.end);
    parent.insertBefore(
      createMatrixSpan(display, token.formatId || detectCipherFormatFromText(display)),
      node
    );
    lastIndex = token.end;
  }

  if (lastIndex < text.length) {
    parent.insertBefore(document.createTextNode(text.slice(lastIndex)), node);
  }

  parent.removeChild(node);
  return true;
}

function isUnifiableContainer(element) {
  if (!element || element.matches(MATRIX_SELECTOR)) {
    return false;
  }

  if (element.closest(MATRIX_SELECTOR)) {
    return false;
  }

  if (SKIP_TAGS.has(element.tagName)) {
    return false;
  }

  for (const child of element.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      continue;
    }

    if (child.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }

    if (child.matches(MATRIX_SELECTOR)) {
      return false;
    }

    if (child.tagName === "SPAN" || child.tagName === "BR") {
      continue;
    }

    return false;
  }

  return true;
}

function containerIsFragmented(element) {
  if (!isUnifiableContainer(element)) {
    return false;
  }

  const fullText = element.textContent || "";
  if (!TextCrypto.hasEncryptedContent(fullText)) {
    return false;
  }

  if (TextCrypto.findTokens(fullText).length === 0) {
    return false;
  }

  const matrixSpans = [...element.querySelectorAll(`:scope > ${MATRIX_SELECTOR}`)];
  if (matrixSpans.length === 1 && matrixSpans[0].textContent.trim() === fullText.trim()) {
    return false;
  }

  const fragmentedChildren = [...element.childNodes].filter((child) => {
    if (child.nodeType === Node.TEXT_NODE) {
      return Boolean(child.nodeValue?.trim());
    }

    return child.nodeType === Node.ELEMENT_NODE && child.tagName === "SPAN";
  });

  return fragmentedChildren.length > 1;
}

function findFragmentedContainers(root = document.body) {
  const containers = new Set();

  if (!root) {
    return [];
  }

  if (root.nodeType === Node.ELEMENT_NODE && containerIsFragmented(root)) {
    containers.add(root);
  }

  for (const element of root.querySelectorAll(TEXT_CONTAINER_SELECTORS)) {
    if (containerIsFragmented(element)) {
      containers.add(element);
    }
  }

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, {
    acceptNode(element) {
      return isUnifiableContainer(element)
        ? NodeFilter.FILTER_ACCEPT
        : NodeFilter.FILTER_REJECT;
    }
  });

  let element = walker.nextNode();
  while (element) {
    if (containerIsFragmented(element)) {
      containers.add(element);
    }

    element = walker.nextNode();
  }

  return [...containers];
}

function containerIsAlreadyStyled(element) {
  const fullText = (element.textContent || "").trim();
  if (!fullText || !TextCrypto.hasEncryptedContent(fullText)) {
    return false;
  }

  const matrixSpans = [...element.querySelectorAll(`:scope > ${MATRIX_SELECTOR}`)];
  if (matrixSpans.length === 1 && matrixSpans[0].textContent.trim() === fullText) {
    return true;
  }

  const tokens = TextCrypto.findTokens(fullText);
  if (tokens.length === 0) {
    return false;
  }

  const directMatrixSpans = matrixSpans.filter((span) =>
    TextCrypto.isEncrypted(span.textContent.trim())
  );

  if (directMatrixSpans.length !== tokens.length) {
    return false;
  }

  let searchFrom = 0;
  for (const span of directMatrixSpans) {
    const cipher = span.textContent.trim();
    const index = fullText.indexOf(cipher, searchFrom);
    if (index === -1) {
      return false;
    }

    searchFrom = index + cipher.length;
  }

  return searchFrom === fullText.length;
}

function rebuildContainerWithEncryptedTokens(element) {
  const fullText = element.textContent || "";
  const tokens = TextCrypto.findTokens(fullText);
  if (tokens.length === 0) {
    return false;
  }

  if (isAlreadyDecrypted(element) || containerIsAlreadyStyled(element)) {
    return false;
  }

  const fragment = document.createDocumentFragment();
  let lastIndex = 0;

  for (const token of tokens) {
    if (token.start > lastIndex) {
      fragment.appendChild(document.createTextNode(fullText.slice(lastIndex, token.start)));
    }

    const display = fullText.slice(token.start, token.end);
    fragment.appendChild(
      createMatrixSpan(display, token.formatId || detectCipherFormatFromText(display))
    );
    lastIndex = token.end;
  }

  if (lastIndex < fullText.length) {
    fragment.appendChild(document.createTextNode(fullText.slice(lastIndex)));
  }

  while (element.firstChild) {
    element.removeChild(element.firstChild);
  }

  element.appendChild(fragment);
  markProcessed(element, fullText);
  return true;
}

async function decryptContainerElement(element) {
  const fullText = element.textContent || "";
  if (!fullText || isAlreadyDecrypted(element)) {
    return 0;
  }

  if (!TextCrypto.hasEncryptedContent(fullText)) {
    return 0;
  }

  const { text, count } = await decryptTextInString(fullText);
  if (count > 0) {
    element.textContent = text;
    markDecrypted(element);
  }

  return count;
}

/**
 * Cheap gate before full DOM walks. Avoids TreeWalker + token recovery on ordinary pages.
 * Prefer known tweet/composer containers; otherwise sample text nodes (full scan only if needed).
 */
function subtreeMightHaveCipher(root) {
  if (!root || typeof TextCrypto === "undefined") {
    return false;
  }

  try {
    if (root.nodeType === Node.TEXT_NODE) {
      return TextCrypto.mightContainCipher(root.nodeValue || "");
    }

    if (root.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }

    if (root.matches?.(MATRIX_SELECTOR) || root.querySelector?.(MATRIX_SELECTOR)) {
      return true;
    }

    // X / Twitter: only scan tweet + composer containers (not the whole feed chrome)
    const containers = root.querySelectorAll?.(TEXT_CONTAINER_SELECTORS);
    if (containers && containers.length > 0) {
      for (const el of containers) {
        if (isAlreadyDecrypted(el)) continue;
        const t = el.textContent || "";
        if (t.length >= 40 && TextCrypto.mightContainCipher(t)) {
          return true;
        }
      }
      const host = (location.hostname || "").toLowerCase();
      if (
        host === "x.com" ||
        host.endsWith(".x.com") ||
        host === "twitter.com" ||
        host.endsWith(".twitter.com")
      ) {
        // Also check root itself if it is a container
        if (root.matches?.(TEXT_CONTAINER_SELECTORS)) {
          const t = root.textContent || "";
          return t.length >= 40 && TextCrypto.mightContainCipher(t);
        }
        return false;
      }
    }

    // Generic pages: limited text-node sample, then bail if nothing cipher-like
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || SKIP_TAGS.has(parent.tagName)) {
          return NodeFilter.FILTER_REJECT;
        }
        const v = node.nodeValue;
        if (!v || v.length < 40) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let checked = 0;
    let current = walker.nextNode();
    while (current && checked < 400) {
      checked += 1;
      if (TextCrypto.mightContainCipher(current.nodeValue || "")) {
        return true;
      }
      current = walker.nextNode();
    }
    return false;
  } catch (_e) {
    // Fail open so we never miss real ciphers if the gate errors
    return true;
  }
}

function applyMatrixStyling(root = document.body) {
  if (!root) {
    return;
  }

  if (!subtreeMightHaveCipher(root)) {
    return;
  }

  for (const container of findFragmentedContainers(root)) {
    if (!isAlreadyDecrypted(container)) {
      rebuildContainerWithEncryptedTokens(container);
    }
  }

  for (const node of collectTextNodes(root)) {
    const parent = node.parentElement;
    if (!parent || isAlreadyDecrypted(parent)) {
      continue;
    }

    // Cheap gate before hasEncryptedContent → findTokens
    if (!TextCrypto.mightContainCipher(node.nodeValue || "")) {
      continue;
    }

    if (TextCrypto.hasEncryptedContent(node.nodeValue)) {
      if (wrapEncryptedTokensInNode(node)) {
        const host = parent.closest(TEXT_CONTAINER_SELECTORS) || parent;
        if (host instanceof Element) {
          markProcessed(host, host.textContent || "");
        }
      }
    }
  }
}

function replaceTextWithEncryptedSpan(node, trimmed, encrypted, formatHint) {
  const original = node.nodeValue;
  const start = original.indexOf(trimmed);
  if (start === -1) {
    return false;
  }

  const before = original.slice(0, start);
  const after = original.slice(start + trimmed.length);
  const parent = node.parentNode;
  if (!parent) {
    return false;
  }

  if (before) {
    parent.insertBefore(document.createTextNode(before), node);
  }

  parent.insertBefore(createMatrixSpan(encrypted, formatHint), node);

  if (after) {
    parent.insertBefore(document.createTextNode(after), node);
  }

  parent.removeChild(node);
  return true;
}

async function encryptSelection(selectedTextFromMenu = "") {
  let text = "";

  // For context menu calls we always get the reliable selectedTextFromMenu.
  // Prefer it, especially on X where live selection disappears quickly.
  if (selectedTextFromMenu) {
    text = selectedTextFromMenu.trim();
  } else {
    text = getSelectedText().trim();
  }

  // If live selection is gone (common on X after right-click), restore the exact range
  // captured at contextmenu time first. This makes getSelectedText() succeed again.
  if (!text) {
    if (restoreCapturedContextMenuRange()) {
      text = getSelectedText().trim();
    }
  }

  // Additional fallback: use the text we captured at the exact right-click moment
  if (!text && lastContextMenuText) {
    text = lastContextMenuText.trim();
    // Try to restore the range too for the later DOM operation
    restoreCapturedContextMenuRange();
  }

  if (!text) {
    throw new Error(I18n.t("errSelectTextFirst"));
  }

  if (TextCrypto.isEncrypted(text)) {
    throw new Error(I18n.t("errAlreadyEncrypted"));
  }

  // Encrypt in background (password never enters this script)
  const encryptedPromise = encryptWithPreferredFormat(text);

  return withExtensionUpdate(async () => {
    let selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      // 1. Try the exact range captured at right-click time (most reliable for X)
      if (restoreCapturedContextMenuRange()) {
        selection = window.getSelection();
      }
    }

    if (!selection || selection.rangeCount === 0) {
      // 2. Live selection may have been lost — try to re-select using the menu text
      let editable = await findEditableContainingText(text, 1200);
      if (editable && text) {
        try { editable.focus(); } catch (_) {}
        const reselected = selectTextInEditable(editable, text);
        if (reselected) {
          selection = window.getSelection();
        }
      }
    }

    let marker;
    let usedRange = false;

    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      lastContextMenuRange = null;
      lastContextMenuText = null; // consumed

      // Prepare using range (preferred when we have a valid selection)
      let matrixSpan = null;
      const container = range.commonAncestorContainer;
      if (container) {
        const el = container.nodeType === Node.TEXT_NODE ? container.parentElement : container;
        if (el && el.closest) {
          matrixSpan = el.closest(MATRIX_SELECTOR);
        }
      }

      if (matrixSpan && matrixSpan.parentNode && matrixSpan.textContent.trim() === text) {
        const parent = matrixSpan.parentNode;
        const refNode = matrixSpan.nextSibling;
        matrixSpan.remove();

        marker = document.createElement("span");
        marker.setAttribute(TEMP_MARKER_ATTR, "true");
        marker.textContent = "\u200B";
        parent.insertBefore(marker, refNode);
      } else {
        range.deleteContents();
        marker = document.createElement("span");
        marker.setAttribute(TEMP_MARKER_ATTR, "true");
        marker.textContent = "\u200B";
        range.insertNode(marker);
      }
      usedRange = true;
    }

    if (!usedRange) {
      // Fallback for right-click on X when range is lost: use direct text search to insert marker
      let targetEd = getActiveEditable();
      if (targetEd && text) {
        marker = insertTempMarkerByTextSearch(targetEd, text);
      }
    }

    // On X.com the composer is very flaky (heavy re-renders, CSP issues). 
    // Wait actively until we find an editable that currently contains our captured text.
    if (!marker && (location.hostname.includes('x.com') || location.hostname.includes('twitter.com'))) {
      const targetEd = await findEditableContainingText(text, 2500);
      if (targetEd && text) {
        try { targetEd.focus(); } catch (_) {}
        await new Promise(r => setTimeout(r, 60));
        marker = insertTempMarkerByTextSearch(targetEd, text);
      }
    }

    if (!marker) {
      throw new Error(I18n.t("errSelectTextFirst"));
    }

    // Wait for encryption
    const encrypted = await encryptedPromise;
    const format = await getPreferredCipherFormat();

    const cipherSpan = createMatrixSpan(encrypted, format);
    marker.replaceWith(cipherSpan);

    // Update selection to the new cipher span (use current selection or create new)
    try {
      const sel = window.getSelection();
      sel.removeAllRanges();
      const newRange = document.createRange();
      newRange.selectNodeContents(cipherSpan);
      sel.addRange(newRange);
    } catch (_) {}

    const inputEditable = getContentEditableRoot(cipherSpan);
    if (inputEditable) {
      notifyContentEditableInput(inputEditable, encrypted);
    }

    return { count: 1 };
  });
}

async function encryptForWindow(selectedTextFromMenu = "") {
  let text = "";

  if (selectedTextFromMenu) {
    text = selectedTextFromMenu.trim();
  } else {
    text = getSelectedText().trim();
  }

  if (!text) {
    if (restoreCapturedContextMenuRange()) {
      text = getSelectedText().trim();
    }
  }

  if (!text && lastContextMenuText) {
    text = lastContextMenuText.trim();
  }

  if (!text) {
    throw new Error(I18n.t("errSelectTextFirst"));
  }

  if (TextCrypto.isEncrypted(text)) {
    throw new Error(I18n.t("errAlreadyEncrypted"));
  }

  // Encrypt in background – do not touch the DOM
  const encrypted = await encryptWithPreferredFormat(text);

  return { encrypted };
}

async function decryptSelection(selectedTextFromMenu = "") {
  let text = getSelectedText().trim();

  // If live selection is gone (common on X after right-click), restore the exact range
  // captured at contextmenu time first.
  if (!text) {
    if (restoreCapturedContextMenuRange()) {
      text = getSelectedText().trim();
    }
  }

  // Additional fallback: use the text we captured at the exact right-click moment
  if (!text && lastContextMenuText) {
    text = lastContextMenuText.trim();
    restoreCapturedContextMenuRange();
  }

  if (!text && selectedTextFromMenu) {
    text = selectedTextFromMenu.trim();
  }
  if (!text) {
    throw new Error(I18n.t("errSelectEncryptedFirst"));
  }

  // Prefer noise-stripped cipher for X.com (ZWSP / soft line breaks in posts)
  const cipherCandidate =
    typeof TextCrypto.normalizeCipherText === "function"
      ? TextCrypto.normalizeCipherText(text)
      : text;
  const decryptSource =
    TextCrypto.isEncrypted(text)
      ? text
      : TextCrypto.isEncrypted(cipherCandidate)
        ? cipherCandidate
        : text;

  if (TextCrypto.isEncrypted(decryptSource)) {
    const decryptedPromise = bgCryptoDecrypt(decryptSource);

    return withExtensionUpdate(async () => {
      let selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) {
        // 1. Try exact captured range from right-click (best for X)
        if (restoreCapturedContextMenuRange()) {
          selection = window.getSelection();
        }
      }

      if (!selection || selection.rangeCount === 0) {
        // 2. Fallback re-select using provided text
        const editable = getActiveEditable();
        if (editable && text) {
          try { editable.focus(); } catch (_) {}
          const reselected = selectTextInEditable(editable, text);
          if (reselected) {
            selection = window.getSelection();
          }
        }
      }

      if (!selection || selection.rangeCount === 0) {
        throw new Error(I18n.t("errSelectEncryptedFirst"));
      }

      const range = selection.getRangeAt(0);
      lastContextMenuRange = null;
      lastContextMenuText = null; // consumed

      // Check if the selection is inside (or is) a matrix cipher span.
      // If yes, we will replace the entire wrapper span to avoid leaving
      // a styled span around the decrypted text.
      let matrixSpan = null;
      const container = range.commonAncestorContainer;
      if (container) {
        const el = container.nodeType === Node.TEXT_NODE ? container.parentElement : container;
        if (el && el.closest) {
          matrixSpan = el.closest(MATRIX_SELECTOR);
        }
      }

      const decrypted = await decryptedPromise;

      if (matrixSpan && matrixSpan.parentNode) {
        const textNode = document.createTextNode(decrypted);
        matrixSpan.replaceWith(textNode);

        selection.removeAllRanges();
        const newRange = document.createRange();
        newRange.selectNodeContents(textNode);
        selection.addRange(newRange);

        const editable = getContentEditableRoot(textNode);
        if (editable) {
          notifyContentEditableInput(editable, decrypted);
          cleanupDecryptedContent(editable);
        }

        return { count: 1 };
      }

      // Fallback for selections not inside a matrix span
      range.deleteContents();

      const marker = document.createElement("span");
      marker.setAttribute(TEMP_MARKER_ATTR, "true");
      marker.textContent = "\u200B";
      range.insertNode(marker);

      const textNode = document.createTextNode(decrypted);
      marker.replaceWith(textNode);

      selection.removeAllRanges();
      const newRange = document.createRange();
      newRange.selectNodeContents(textNode);
      selection.addRange(newRange);

      const editable = getContentEditableRoot(textNode);
      if (editable) {
        notifyContentEditableInput(editable, decrypted);
        cleanupDecryptedContent(editable);
      }

      return { count: 1 };
    });
  }

  let tokens = TextCrypto.findTokens(text);
  if (tokens.length === 0 && cipherCandidate && cipherCandidate !== text) {
    tokens = TextCrypto.findTokens(cipherCandidate);
    // Positions are for cleaned string → treat whole selection as one block
    if (tokens.length > 0) {
      tokens = tokens.map((t) => ({
        start: 0,
        end: text.length,
        cipher: t.cipher
      }));
      // One combined replace is enough when whole selection is noise-laden cipher
      tokens = [tokens[0]];
    }
  }
  if (tokens.length === 0) {
    throw new Error(I18n.t("errNotEncrypted"));
  }

  let result = text;
  let count = 0;

  const ordered = tokens.slice().reverse();
  const decResults = await bgCryptoDecryptMany(ordered.map((t) => t.cipher));
  for (let i = 0; i < ordered.length; i++) {
    const token = ordered[i];
    const dec = decResults[i];
    if (dec && dec.ok && dec.plaintext != null) {
      result = result.slice(0, token.start) + dec.plaintext + result.slice(token.end);
      count += 1;
    }
  }

  if (count === 0) {
    throw new Error(I18n.t("errDecryptFailed"));
  }

  // Capture range before the final replacement (the awaits above could have taken time)
  const selection = window.getSelection();
  let savedRange = null;
  if (selection && selection.rangeCount > 0) {
    try {
      savedRange = selection.getRangeAt(0).cloneRange();
    } catch (_) {}
  }

  return withExtensionUpdate(async () => {
    if (savedRange) {
      try {
        selection.removeAllRanges();
        selection.addRange(savedRange);
      } catch (_) {}
    }
    replaceSelection(result);

    // Cleanup after token-based decrypt
    const editable = getActiveEditable();
    if (editable) {
      cleanupDecryptedContent(editable);
    }

    return { count };
  });
}

async function decryptTextInString(text) {
  if (!TextCrypto.hasEncryptedContent(text)) {
    return { text, count: 0 };
  }

  const tokens = TextCrypto.findTokens(text);
  let result = text;
  let count = 0;

  const ordered = tokens.slice().reverse();
  const decResults = await bgCryptoDecryptMany(ordered.map((t) => t.cipher));
  for (let i = 0; i < ordered.length; i++) {
    const token = ordered[i];
    const dec = decResults[i];
    if (dec && dec.ok && dec.plaintext != null) {
      result = result.slice(0, token.start) + dec.plaintext + result.slice(token.end);
      count += 1;
    }
  }

  return { text: result, count };
}

async function decryptTextNode(node) {
  const { text, count } = await decryptTextInString(node.nodeValue);
  if (count > 0) {
    node.nodeValue = text;
  }
  return count;
}

async function decryptMatrixSpans() {
  const spans = [...document.querySelectorAll(MATRIX_SELECTOR)];
  let count = 0;

  const work = [];
  for (const span of spans) {
    const host = span.closest(TEXT_CONTAINER_SELECTORS);
    if (host && isAlreadyDecrypted(host)) {
      continue;
    }

    const cipher = span.textContent.trim();
    if (!TextCrypto.isEncrypted(cipher)) {
      continue;
    }
    work.push({ span, host, cipher });
  }

  if (work.length === 0) {
    return 0;
  }

  const decResults = await bgCryptoDecryptMany(work.map((w) => w.cipher));
  for (let i = 0; i < work.length; i++) {
    const dec = decResults[i];
    if (!dec || !dec.ok || dec.plaintext == null) {
      continue;
    }
    const { span, host } = work[i];
    if (!span.parentNode) {
      continue;
    }
    span.replaceWith(document.createTextNode(dec.plaintext));
    if (host instanceof Element) {
      markDecrypted(host);
    }
    count += 1;
  }

  return count;
}

async function transformPage(mode, options = {}) {
  return withExtensionUpdate(async () => {
    let count = 0;

    if (mode === "decrypt") {
      count += await decryptMatrixSpans();

      const containers = new Set([
        ...document.querySelectorAll(TEXT_CONTAINER_SELECTORS),
        ...findFragmentedContainers(document.body)
      ]);

      for (const container of containers) {
        count += await decryptContainerElement(container);
      }
    }

    const nodes = collectTextNodes(document.body);

    for (const node of nodes) {
      const original = node.nodeValue;
      const trimmed = original.trim();
      if (!trimmed) {
        continue;
      }

      const host = node.parentElement?.closest(TEXT_CONTAINER_SELECTORS);
      if (mode === "decrypt" && host && isAlreadyDecrypted(host)) {
        continue;
      }

      try {
        if (mode === "encrypt") {
          if (TextCrypto.isEncrypted(trimmed)) {
            continue;
          }

          const format = await getPreferredCipherFormat();
          const encrypted = await bgCryptoEncrypt(trimmed, format);
          if (replaceTextWithEncryptedSpan(node, trimmed, encrypted, format)) {
            count += 1;
          }
        } else {
          const nodeCount = await decryptTextNode(node);
          if (nodeCount > 0 && host instanceof Element) {
            markDecrypted(host);
          }
          count += nodeCount;
        }
      } catch (_error) {
        // Einzelne Knoten überspringen, z. B. falsches Passwort.
      }
    }

    if (count === 0 && !options.silent) {
      throw new Error(
        mode === "encrypt" ? I18n.t("errNoPlaintextFound") : I18n.t("errNoDecryptableFound")
      );
    }

    return { count };
  });
}

/** Cached auto-decrypt prefs — storage/bg round-trips on every mutation were costly. */
let cachedAutoDecryptSettings = null;
let cachedAutoDecryptAt = 0;
const SETTINGS_CACHE_MS = 2000;

async function getAutoDecryptSettings(options = {}) {
  const force = Boolean(options.force);
  const now = Date.now();
  if (
    !force &&
    cachedAutoDecryptSettings &&
    now - cachedAutoDecryptAt < SETTINGS_CACHE_MS
  ) {
    return cachedAutoDecryptSettings;
  }

  const localData = await browser.storage.local.get(["autoDecrypt", "matrixColor", "cipherFormat"]);

  // Update color cache
  if (localData.matrixColor && MATRIX_COLORS[localData.matrixColor]) {
    const colorChanged = localData.matrixColor !== currentMatrixColor;
    currentMatrixColor = localData.matrixColor;
    currentMatrixShadow = MATRIX_COLORS[localData.matrixColor];
    // Only re-style existing spans when color actually changed
    if (colorChanged) {
      document.querySelectorAll(`[${MATRIX_ATTR}="true"]`).forEach((span) => {
        applyMatrixSpanStyles(span);
      });
    }
  }

  const hasPassword = await bgHasPassword();

  cachedAutoDecryptSettings = {
    autoDecrypt: Boolean(localData.autoDecrypt),
    hasPassword
  };
  cachedAutoDecryptAt = now;
  return cachedAutoDecryptSettings;
}

let contentProcessingTimer = null;
/** Roots that need styling/decrypt (scoped instead of always walking document.body). */
const pendingProcessRoots = new Set();

function addPendingRoot(node) {
  if (!node) {
    if (document.body) pendingProcessRoots.add(document.body);
    return;
  }
  if (node.nodeType === Node.TEXT_NODE) {
    if (node.parentElement) pendingProcessRoots.add(node.parentElement);
    return;
  }
  if (node.nodeType === Node.ELEMENT_NODE) {
    pendingProcessRoots.add(node);
    return;
  }
  if (document.body) pendingProcessRoots.add(document.body);
}

function takePendingRoots() {
  if (pendingProcessRoots.size === 0) {
    return document.body ? [document.body] : [];
  }
  const roots = [...pendingProcessRoots];
  pendingProcessRoots.clear();

  // If body is pending, just process body once
  if (roots.some((r) => r === document.body)) {
    return document.body ? [document.body] : [];
  }

  // Drop roots that are descendants of another pending root
  const filtered = [];
  for (const root of roots) {
    if (!root.isConnected) continue;
    const covered = filtered.some((other) => other.contains(root));
    if (covered) continue;
    // Remove previous roots that this one contains
    for (let i = filtered.length - 1; i >= 0; i--) {
      if (root.contains(filtered[i])) {
        filtered.splice(i, 1);
      }
    }
    filtered.push(root);
  }
  return filtered.length > 0 ? filtered : document.body ? [document.body] : [];
}

function scheduleContentProcessing(fromNode) {
  if (extensionIsUpdating) {
    return;
  }

  // Skip if user currently has text selected (prevents breaking double-click selection on X)
  const currentSel = window.getSelection && window.getSelection();
  if (currentSel && currentSel.toString().trim().length > 0) {
    return;
  }

  addPendingRoot(fromNode);

  clearTimeout(contentProcessingTimer);
  // 450ms debounce: SPAs (X) emit many mutations; avoid full rescans per tick
  contentProcessingTimer = setTimeout(async () => {
    const { autoDecrypt, hasPassword } = await getAutoDecryptSettings();
    const roots = takePendingRoots();

    await withExtensionUpdate(async () => {
      if (autoDecrypt && hasPassword) {
        // Full-page decrypt only when auto-decrypt is on; still gate on cipher presence
        if (subtreeMightHaveCipher(document.body)) {
          await transformPage("decrypt", { silent: true });
        }
        return;
      }

      for (const root of roots) {
        if (root && root.isConnected) {
          applyMatrixStyling(root);
        }
      }
    });
  }, 450);
}

/**
 * Observer-side filter: only use cheap mightContainCipher.
 * Full hasEncryptedContent/findTokens runs later in the debounced processor.
 */
function nodeMightNeedProcessing(node) {
  if (isExtensionNode(node)) {
    return false;
  }

  if (node.nodeType === Node.TEXT_NODE) {
    const parent = node.parentElement;
    if (parent?.closest(`[${DECRYPTED_ATTR}]`)) {
      return false;
    }
    return TextCrypto.mightContainCipher(node.nodeValue || "");
  }

  if (node.nodeType === Node.ELEMENT_NODE) {
    if (node.matches?.(MATRIX_SELECTOR)) {
      return true;
    }
    if (node.matches?.(TEXT_CONTAINER_SELECTORS) && isAlreadyDecrypted(node)) {
      return false;
    }

    if (node.matches?.(TEXT_CONTAINER_SELECTORS)) {
      return TextCrypto.mightContainCipher(node.textContent || "");
    }

    if (node.querySelector?.(TEXT_CONTAINER_SELECTORS)) {
      const containers = node.querySelectorAll(TEXT_CONTAINER_SELECTORS);
      for (const container of containers) {
        if (isAlreadyDecrypted(container)) continue;
        if (TextCrypto.mightContainCipher(container.textContent || "")) {
          return true;
        }
      }
      // On X, ignore feed chrome without tweet text containers of interest
      const host = (location.hostname || "").toLowerCase();
      if (
        host === "x.com" ||
        host.endsWith(".x.com") ||
        host === "twitter.com" ||
        host.endsWith(".twitter.com")
      ) {
        return false;
      }
    }

    // Cap cost: don't run expensive scans on huge subtrees in the observer hot path
    const t = node.textContent || "";
    if (t.length > 120000) {
      const sample = t.slice(0, 60000) + t.slice(-20000);
      return TextCrypto.mightContainCipher(sample);
    }
    return TextCrypto.mightContainCipher(t);
  }

  return false;
}

function startAutoDecryptWatcher() {
  scheduleContentProcessing(document.body);

  const observer = new MutationObserver((mutations) => {
    if (extensionIsUpdating) {
      return;
    }

    // Don't interfere if user is currently selecting text (e.g. double-click to mark)
    const currentSel = window.getSelection && window.getSelection();
    if (currentSel && currentSel.toString().trim().length > 0) {
      return;
    }

    // Cap work per observer callback (X fires huge mutation batches)
    const maxMutations = Math.min(mutations.length, 40);
    let relevantNode = null;

    for (let i = 0; i < maxMutations; i++) {
      const mutation = mutations[i];
      if (isExtensionNode(mutation.target)) {
        continue;
      }

      if (mutation.type === "characterData") {
        if (nodeMightNeedProcessing(mutation.target)) {
          relevantNode = mutation.target;
          break;
        }
        continue;
      }

      if (mutation.type === "childList") {
        const added = mutation.addedNodes;
        const limit = Math.min(added.length, 20);
        for (let j = 0; j < limit; j++) {
          if (nodeMightNeedProcessing(added[j])) {
            relevantNode = added[j];
            break;
          }
        }
        if (relevantNode) break;
      }
    }

    if (relevantNode) {
      scheduleContentProcessing(relevantNode);
    }
  });

  if (document.body) {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      // characterData is expensive on SPAs; only watch it when nodes are edited in place
      characterData: true,
      characterDataOldValue: false
    });
  }
}

/**
 * Detect Enigma QR decrypt landing pages (GitHub Pages or similar).
 * If a session password is stored, decrypt the #c= cipher and show the result.
 */
function isEnigmaDecryptLandingPage() {
  try {
    const path = (location.pathname || "").toLowerCase();
    if (!path.endsWith("decrypt.html") && path.indexOf("/decrypt.html") === -1) {
      return false;
    }
    // Public scan page or any hosted decrypt.html with #c=
    return Boolean(location.hash && location.hash.length > 3);
  } catch (_) {
    return false;
  }
}

function extractCipherFromDecryptLanding() {
  try {
    const hash = (location.hash || "").replace(/^#/, "");
    let raw = "";
    if (hash.startsWith("c=")) {
      raw = hash.slice(2);
    } else if (hash.startsWith("d=")) {
      raw = hash.slice(2);
    } else {
      raw = hash;
    }
    try {
      raw = decodeURIComponent(raw);
    } catch (_) {}
    return (raw || "").trim();
  } catch (_) {
    return "";
  }
}

async function tryAutoDecryptLandingPage() {
  if (!isEnigmaDecryptLandingPage()) {
    return;
  }

  const cipher = extractCipherFromDecryptLanding();
  if (!cipher || !TextCrypto.isEncrypted(cipher)) {
    return;
  }

  if (!(await bgHasPassword())) {
    // Leave the page's manual password form as-is
    return;
  }

  try {
    const plain = await bgCryptoDecrypt(cipher);

    const resultEl = document.getElementById("result");
    if (resultEl) {
      resultEl.textContent = plain;
    }

    const statusEl = document.getElementById("status");
    if (statusEl) {
      statusEl.textContent = "Automatisch mit Enigma-Addon entschlüsselt.";
      statusEl.className = "status ok";
    }

    const badge = document.getElementById("badge");
    if (badge) {
      badge.textContent = "Entschlüsselt (Addon)";
      badge.className = "badge";
    }

    const pw = document.getElementById("password");
    if (pw) {
      pw.value = "";
      pw.placeholder = "Mit Addon-Sitzung entschlüsselt";
    }

    try {
      window.postMessage(
        { type: "ENIGMA_DECRYPT_RESULT", ok: true, plaintext: plain },
        location.origin
      );
    } catch (_) {}
  } catch (_error) {
    try {
      window.postMessage(
        {
          type: "ENIGMA_DECRYPT_RESULT",
          ok: false,
          error: "Addon-Passwort passt nicht – bitte manuell eingeben."
        },
        location.origin
      );
    } catch (_) {}
  }
}

async function bootContentScript() {
  // Defer heavy work slightly so first paint of the host page is not blocked
  // (content script still loads at document_idle; this yields one more task).
  await new Promise((resolve) => {
    if (typeof requestIdleCallback === "function") {
      requestIdleCallback(() => resolve(), { timeout: 200 });
    } else {
      setTimeout(resolve, 0);
    }
  });

  await I18n.init();

  // QR scan landing page: auto-decrypt via background when session password exists
  await tryAutoDecryptLandingPage();

  await withExtensionUpdate(async () => {
    const { autoDecrypt, hasPassword } = await getAutoDecryptSettings({ force: true });
    if (autoDecrypt && hasPassword) {
      if (subtreeMightHaveCipher(document.body)) {
        await transformPage("decrypt", { silent: true });
      }
    } else {
      applyMatrixStyling(document.body);
    }
  });

  startAutoDecryptWatcher();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootContentScript, { once: true });
} else {
  bootContentScript();
}

browser.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local") {
    // Invalidate settings cache on any relevant local change
    if (changes.autoDecrypt || changes.matrixColor || changes.cipherFormat) {
      cachedAutoDecryptSettings = null;
      cachedAutoDecryptAt = 0;
    }

    if (changes.autoDecrypt) {
      scheduleContentProcessing(document.body);
    }

    if (changes.matrixColor && MATRIX_COLORS[changes.matrixColor.newValue]) {
      currentMatrixColor = changes.matrixColor.newValue;
      currentMatrixShadow = MATRIX_COLORS[changes.matrixColor.newValue];
      // Re-apply to existing spans so no flicker with old color
      document.querySelectorAll(`[${MATRIX_ATTR}="true"]`).forEach((span) => {
        applyMatrixSpanStyles(span);
      });
    }

    if (changes[I18n.STORAGE_KEY]) {
      I18n.setLocale(changes[I18n.STORAGE_KEY].newValue || "", { persist: false });
    }
  }

  if (areaName === "session" && changes.password) {
    // Password availability changed – never read the value here
    cachedAutoDecryptSettings = null;
    cachedAutoDecryptAt = 0;
    scheduleContentProcessing(document.body);
  }
});

// The early registration (near top of file) points to this function.
// Defined here so that all other functions are in scope.
// Password is never accepted or used in content scripts.
function onRuntimeMessage(message, _sender, sendResponse) {
  const run = async () => {
    await I18n.init();

    if (!message || !message.action) {
      throw new Error(I18n.t("errUnknownAction"));
    }

    switch (message.action) {
      case "encrypt-selection":
        return encryptSelection(message.selectedText || "");
      case "encrypt-window":
        return encryptForWindow(message.selectedText || "");
      case "decrypt-selection":
        return decryptSelection(message.selectedText || "");
      case "encrypt-page":
        return transformPage("encrypt");
      case "decrypt-page":
        return transformPage("decrypt");
      default:
        throw new Error(I18n.t("errUnknownAction"));
    }
  };

  run()
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
}
