const passwordInput = document.getElementById("password");
const rememberInput = document.getElementById("remember");
const autoDecryptInput = document.getElementById("auto-decrypt");
const languageSelect = document.getElementById("language");
const matrixColorSelect = document.getElementById("matrix-color");
const cipherFormatSelect = document.getElementById("cipher-format");
const statusEl = document.getElementById("status");

const CIPHER_FORMATS = ["katakana", "runes", "braille", "zalgo", "mixed"];
const DEFAULT_CIPHER_FORMAT = "katakana";

// Same visual rain alphabet as lib/crypto.js (ciphertext look)
const MATRIX_CHARS =
  "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝｦｯｰ012345789Z:.=*+-※";

const actions = {
  "encrypt-selection": "encrypt-selection",
  "decrypt-selection": "decrypt-selection",
  "encrypt-page": "encrypt-page",
  "decrypt-page": "decrypt-page"
};

/* ── Matrix rain background (calm, slow drift) ── */
let matrixCanvas = null;
let matrixCtx = null;
let matrixAnimationId = null;
let matrixDrops = [];
let matrixDropSpeed = [];
let matrixDropChars = [];
let matrixResizeObserver = null;
let matrixLastFrameTs = 0;
/** Rain glyph size (readable, not oversized) */
const MATRIX_FONT_SIZE = 22;
const MATRIX_COL_GAP = 24;
/** Target frame interval — ~24fps is calmer than 60fps full blast */
const MATRIX_FRAME_MS = 42;
/** Vertical speed in cells per second */
const MATRIX_SPEED_MIN = 4.5;
const MATRIX_SPEED_MAX = 8.5;
/** Clear system fonts — EnigmaRain is too abstract at rain size */
const MATRIX_RAIN_FONT = `${MATRIX_FONT_SIZE}px "MS Gothic", "Yu Gothic", "Meiryo", "Consolas", "Courier New", monospace`;

function stopMatrixRain() {
  if (matrixAnimationId) {
    cancelAnimationFrame(matrixAnimationId);
    matrixAnimationId = null;
  }
  matrixLastFrameTs = 0;
}

function initMatrixDrops(w) {
  const cols = Math.floor(w / MATRIX_COL_GAP);
  matrixDrops = new Array(cols);
  matrixDropSpeed = new Array(cols);
  matrixDropChars = new Array(cols);
  for (let i = 0; i < cols; i++) {
    matrixDrops[i] = Math.random() * -40;
    matrixDropSpeed[i] =
      MATRIX_SPEED_MIN + Math.random() * (MATRIX_SPEED_MAX - MATRIX_SPEED_MIN);
    matrixDropChars[i] = MATRIX_CHARS.charAt(
      Math.floor(Math.random() * MATRIX_CHARS.length)
    );
  }
}

function drawMatrixRain(ts) {
  if (!matrixCtx || !matrixCanvas) return;

  if (typeof ts !== "number") {
    ts = performance.now();
  }

  // Throttle draw rate — calm speed, still room for head blink
  if (matrixLastFrameTs && ts - matrixLastFrameTs < MATRIX_FRAME_MS) {
    matrixAnimationId = requestAnimationFrame(drawMatrixRain);
    return;
  }
  const dt = matrixLastFrameTs ? Math.min(0.08, (ts - matrixLastFrameTs) / 1000) : 0.042;
  matrixLastFrameTs = ts;

  const w = matrixCanvas.width;
  const h = matrixCanvas.height;

  // Short trails: fade canvas quickly so glyphs don't smear into green streaks
  matrixCtx.fillStyle = "rgba(0, 0, 0, 0.22)";
  matrixCtx.fillRect(0, 0, w, h);

  matrixCtx.font = MATRIX_RAIN_FONT;
  matrixCtx.textBaseline = "top";
  matrixCtx.imageSmoothingEnabled = false;

  for (let i = 0; i < matrixDrops.length; i++) {
    // Glyph flicker: swap often enough to feel alive, not every frame
    if (Math.random() > 0.78) {
      matrixDropChars[i] = MATRIX_CHARS.charAt(
        Math.floor(Math.random() * MATRIX_CHARS.length)
      );
    }
    const char = matrixDropChars[i];
    const x = i * MATRIX_COL_GAP;
    const y = matrixDrops[i] * MATRIX_FONT_SIZE;

    // Soft body trail (only 1 step)
    const trailY = y - MATRIX_FONT_SIZE;
    if (trailY > -MATRIX_FONT_SIZE) {
      matrixCtx.shadowBlur = 16;
      matrixCtx.shadowColor = "rgba(0, 255, 65, 0.75)";
      matrixCtx.fillStyle = "#00cc33";
      matrixCtx.globalAlpha = 0.4;
      matrixCtx.fillText(char, x, trailY);
    }

    // Head: strong multi-pass glow + blink
    const blink = Math.random();
    if (blink > 0.12) {
      const flash = blink > 0.88;
      // wide outer halo
      matrixCtx.shadowBlur = flash ? 42 : 32;
      matrixCtx.shadowColor = flash
        ? "rgba(220, 255, 220, 1)"
        : "rgba(0, 255, 80, 1)";
      matrixCtx.fillStyle = flash ? "#ffffff" : "#7dff55";
      matrixCtx.globalAlpha = flash ? 1 : 0.85;
      matrixCtx.fillText(char, x, y);
      // mid glow
      matrixCtx.shadowBlur = flash ? 36 : 26;
      matrixCtx.shadowColor = "rgba(0, 255, 65, 0.95)";
      matrixCtx.globalAlpha = flash ? 0.85 : 0.7;
      matrixCtx.fillStyle = flash ? "#f5fff5" : "#5cff3a";
      matrixCtx.fillText(char, x, y);
      // core (sharp + bright)
      matrixCtx.shadowBlur = flash ? 20 : 14;
      matrixCtx.globalAlpha = 1;
      matrixCtx.fillStyle = flash ? "#ffffff" : "#b8ff9a";
      matrixCtx.fillText(char, x, y);
    } else {
      // brief dim pulse (still heavy glow)
      matrixCtx.shadowBlur = 24;
      matrixCtx.shadowColor = "rgba(0, 255, 65, 0.8)";
      matrixCtx.fillStyle = "#00ff41";
      matrixCtx.globalAlpha = 0.5;
      matrixCtx.fillText(char, x, y);
    }
    matrixCtx.shadowBlur = 0;
    matrixCtx.shadowColor = "transparent";

    matrixDrops[i] += matrixDropSpeed[i] * dt;

    if (y > h + 24 && Math.random() > 0.985) {
      matrixDrops[i] = Math.random() * -18;
      matrixDropSpeed[i] =
        MATRIX_SPEED_MIN + Math.random() * (MATRIX_SPEED_MAX - MATRIX_SPEED_MIN);
    }
  }

  matrixCtx.globalAlpha = 1;
  matrixAnimationId = requestAnimationFrame(drawMatrixRain);
}

function getPopupDimensions() {
  const mainEl = document.querySelector("main");
  // Match classic desktop popup (~320 wide); height follows content
  let w = 320;
  let h = 400;

  if (mainEl) {
    const rect = mainEl.getBoundingClientRect();
    w = Math.max(w, Math.ceil(rect.width) + 2);
    h = Math.max(h, Math.ceil(rect.height) + 8);
  }

  w = Math.max(w, document.body.clientWidth || document.documentElement.clientWidth || 320);
  h = Math.max(h, document.body.clientHeight || document.documentElement.clientHeight || 400);
  w = Math.max(300, Math.min(w, 360));
  h = Math.max(280, h);

  return { w, h };
}

function resizeMatrixCanvas() {
  if (!matrixCanvas) return;

  const { w, h } = getPopupDimensions();
  matrixCanvas.width = w;
  matrixCanvas.height = h;

  // Fill solid black first so no blue flash
  matrixCtx.fillStyle = "#000000";
  matrixCtx.fillRect(0, 0, w, h);

  initMatrixDrops(w);
  stopMatrixRain();
  drawMatrixRain();
}

function initMatrixBackground() {
  if (matrixCanvas) {
    resizeMatrixCanvas();
    return;
  }

  matrixCanvas = document.createElement("canvas");
  matrixCanvas.id = "matrix-bg";
  document.body.insertBefore(matrixCanvas, document.body.firstChild);
  matrixCtx = matrixCanvas.getContext("2d", { alpha: false });

  resizeMatrixCanvas();

  if (window.ResizeObserver) {
    matrixResizeObserver = new ResizeObserver(() => {
      clearTimeout(matrixCanvas._resizeTimer);
      matrixCanvas._resizeTimer = setTimeout(resizeMatrixCanvas, 40);
    });
    matrixResizeObserver.observe(document.body);
    const mainEl = document.querySelector("main");
    if (mainEl) matrixResizeObserver.observe(mainEl);
  }

  // Popups often resize after open – remeasure a few times
  setTimeout(resizeMatrixCanvas, 50);
  setTimeout(resizeMatrixCanvas, 150);
  setTimeout(resizeMatrixCanvas, 300);

  // Collapsible panels change height – keep Matrix rain sized
  document.querySelectorAll("details.panel").forEach((panel) => {
    panel.addEventListener("toggle", () => {
      setTimeout(resizeMatrixCanvas, 30);
    });
  });
}

function setStatus(message, type = "") {
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.className = `status ${type}`.trim();
}

function populateLanguageSelect(selectedLocale = "") {
  const stored = selectedLocale && selectedLocale !== "auto" ? selectedLocale : "auto";
  languageSelect.innerHTML = "";

  const autoOption = document.createElement("option");
  autoOption.value = "auto";
  autoOption.textContent = I18n.t("optionLanguageAuto");
  languageSelect.appendChild(autoOption);

  for (const locale of I18n.getSupportedLocales()) {
    const option = document.createElement("option");
    option.value = locale.code;
    option.textContent = locale.label;
    languageSelect.appendChild(option);
  }

  languageSelect.value = stored;
}

async function applyTranslations() {
  I18n.applyToDocument();
  populateLanguageSelect(languageSelect.value || "auto");
}

/**
 * Password lives only in browser.storage.session (never storage.local).
 * Falls back to background message API if session API is flaky.
 */
async function sessionPasswordGet() {
  try {
    if (browser.storage && browser.storage.session) {
      return await browser.storage.session.get(["password", "remember"]);
    }
  } catch (_e) {}
  return {};
}

async function saveSessionPassword() {
  const password = passwordInput ? passwordInput.value.trim() : "";
  const remember = Boolean(rememberInput && rememberInput.checked);

  try {
    if (browser.storage && browser.storage.session) {
      if (remember && password) {
        await browser.storage.session.set({ password, remember: true });
      } else {
        await browser.storage.session.remove(["password", "remember"]);
      }
      return;
    }
  } catch (_e) {}

  try {
    await browser.runtime.sendMessage({
      type: "set-session-password",
      password: remember ? password : "",
      remember
    });
  } catch (_e2) {}
}

async function loadSettings() {
  let sessionData = {};
  let localData = {};
  try {
    // Drop any legacy local password left by older versions
    browser.storage.local.remove("password").catch(() => {});

    [sessionData, localData] = await Promise.all([
      sessionPasswordGet(),
      browser.storage.local.get(["autoDecrypt", I18n.STORAGE_KEY, "matrixColor", "cipherFormat"])
    ]);
  } catch (e) {
    console.warn("Enigma: loadSettings failed", e);
  }

  if (sessionData.password && passwordInput) {
    passwordInput.value = sessionData.password;
  }
  if (rememberInput) rememberInput.checked = Boolean(sessionData.remember);
  if (autoDecryptInput) autoDecryptInput.checked = Boolean(localData.autoDecrypt);

  const storedLocale = localData[I18n.STORAGE_KEY] || "auto";
  if (languageSelect) populateLanguageSelect(storedLocale);

  if (cipherFormatSelect) {
    const fmt = localData.cipherFormat || DEFAULT_CIPHER_FORMAT;
    cipherFormatSelect.value = CIPHER_FORMATS.includes(fmt) ? fmt : DEFAULT_CIPHER_FORMAT;
  }

  if (matrixColorSelect) {
    matrixColorSelect.value = localData.matrixColor || "#00ff41";
  }
}

async function saveAutoDecryptSetting() {
  await browser.storage.local.set({
    autoDecrypt: autoDecryptInput.checked
  });
}

async function saveMatrixColorSetting() {
  await browser.storage.local.set({
    matrixColor: matrixColorSelect.value
  });
}

function formatLabelForStatus(format) {
  const keyByFormat = {
    katakana: "optionFormatKatakana",
    runes: "optionFormatRunes",
    braille: "optionFormatBraille",
    zalgo: "optionFormatZalgo",
    mixed: "optionFormatMixed"
  };
  const name = I18n.t(keyByFormat[format] || "optionFormatKatakana");
  return I18n.t("statusCipherFormat", name);
}

async function saveCipherFormatSetting() {
  const value = cipherFormatSelect ? cipherFormatSelect.value : DEFAULT_CIPHER_FORMAT;
  const format = CIPHER_FORMATS.includes(value) ? value : DEFAULT_CIPHER_FORMAT;
  await browser.storage.local.set({ cipherFormat: format });
  setStatus(formatLabelForStatus(format), "ok");
}

async function getActiveTab() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function runAction(action) {
  const password = passwordInput.value.trim();
  if (!password) {
    setStatus(I18n.t("errPasswordRequired"), "error");
    return;
  }

  const tab = await getActiveTab();
  if (!tab?.id) {
    setStatus(I18n.t("errNoActiveTab"), "error");
    return;
  }

  setStatus(I18n.t("statusWorking"));

  try {
    // Background holds the password and performs crypto; content never sees it.
    const response = await browser.runtime.sendMessage({
      type: "run-content-action",
      action,
      password,
      remember: Boolean(rememberInput && rememberInput.checked),
      tabId: tab.id
    });
    if (!response?.ok) {
      throw new Error(response?.error || I18n.t("errUnknown"));
    }

    const suffix =
      response.count === 1
        ? I18n.t("statusDoneSingular")
        : I18n.t("statusDonePlural", String(response.count));
    setStatus(suffix, "ok");
  } catch (error) {
    const msg = error && error.message ? error.message : String(error);
    if (msg.includes("Could not establish connection") || msg.includes("Receiving end does not exist") || msg.includes("Content Script")) {
      setStatus(I18n.t("errContentScriptMissing"), "error");
    } else {
      setStatus(msg || I18n.t("errUnknown"), "error");
    }
  }
}

for (const [buttonId, action] of Object.entries(actions)) {
  const btn = document.getElementById(buttonId);
  if (btn) btn.addEventListener("click", () => runAction(action));
}

if (rememberInput) rememberInput.addEventListener("change", saveSessionPassword);
if (passwordInput) passwordInput.addEventListener("input", saveSessionPassword);
if (autoDecryptInput) {
  autoDecryptInput.addEventListener("change", async () => {
    if (autoDecryptInput.checked) {
      const password = passwordInput ? passwordInput.value.trim() : "";
      if (!password) {
        autoDecryptInput.checked = false;
        setStatus(I18n.t("errPasswordFirst"), "error");
        return;
      }

      if (rememberInput) rememberInput.checked = true;
      await saveSessionPassword();
    }

    await saveAutoDecryptSetting();

    setStatus(
      autoDecryptInput.checked ? I18n.t("statusAutoDecryptOn") : I18n.t("statusAutoDecryptOff"),
      "ok"
    );
  });
}

if (languageSelect) {
  languageSelect.addEventListener("change", async () => {
    const value = languageSelect.value;
    await I18n.setLocale(value === "auto" ? "" : value);
    await applyTranslations();
  });
}

if (matrixColorSelect) matrixColorSelect.addEventListener("change", saveMatrixColorSetting);
if (cipherFormatSelect) {
  cipherFormatSelect.addEventListener("change", saveCipherFormatSetting);
}

async function decryptCipherFromPopup() {
  const cipherInput = document.getElementById("cipher-input");
  const resultEl = document.getElementById("cipher-result");
  const password = passwordInput.value.trim();
  let cipher = (cipherInput && cipherInput.value.trim()) || "";

  // Allow pasting full QR URL and extract #c=
  if (cipher.indexOf("#c=") !== -1 || cipher.indexOf("http") === 0) {
    try {
      const hashIdx = cipher.indexOf("#c=");
      if (hashIdx !== -1) {
        cipher = decodeURIComponent(cipher.slice(hashIdx + 3));
      }
    } catch (_) {}
  }
  cipher = cipher.replace(/^web\+enigma:\/*/i, "").trim();

  if (!password) {
    setStatus(I18n.t("errPasswordRequired"), "error");
    return;
  }
  if (!cipher) {
    setStatus(I18n.t("errCipherRequired"), "error");
    return;
  }

  await saveSessionPassword();
  setStatus(I18n.t("statusWorking"));

  try {
    const response = await browser.runtime.sendMessage({
      type: "crypto-decrypt",
      ciphertext: cipher,
      password
    });
    if (!response || !response.ok) {
      throw new Error((response && response.error) || "decrypt failed");
    }
    if (resultEl) resultEl.value = response.plaintext;
    setStatus(I18n.t("statusCipherDecrypted"), "ok");
  } catch (err) {
    if (resultEl) resultEl.value = "";
    setStatus(I18n.t("errDecryptFailed"), "error");
  }
}

const decryptCipherBtn = document.getElementById("decrypt-cipher");
if (decryptCipherBtn) {
  decryptCipherBtn.addEventListener("click", decryptCipherFromPopup);
}

/* ── Dedicated windows: file picker kills the toolbar popup ── */
const voiceOpenBtn = document.getElementById("voice-open");
const imageOpenBtn = document.getElementById("image-open");

async function openExtensionWindow(page, size, statusKey) {
  await saveSessionPassword();
  const url = browser.runtime.getURL(page);
  const width = (size && size.width) || 400;
  const height = (size && size.height) || 520;

  const canPopup =
    browser.windows && typeof browser.windows.create === "function";

  if (canPopup) {
    try {
      await browser.windows.create({
        url,
        type: "popup",
        width,
        height,
        left: 90,
        top: 60
      });
      setStatus(I18n.t(statusKey) || "OK", "ok");
      return;
    } catch (_e) {
      // fall through to tab
    }
  }

  try {
    await browser.tabs.create({ url });
    setStatus(I18n.t(statusKey) || "OK", "ok");
  } catch (err) {
    setStatus((err && err.message) || I18n.t("errUnknown"), "error");
  }
}

async function openVoiceWindow() {
  await openExtensionWindow("voice-window.html", { width: 400, height: 620 }, "statusVoiceWindowOpened");
}

async function openImageWindow() {
  const password = passwordInput ? passwordInput.value.trim() : "";
  if (!password) {
    setStatus(I18n.t("errPasswordRequired"), "error");
    return;
  }
  await openExtensionWindow("image-window.html", { width: 400, height: 560 }, "statusImageWindowOpened");
}

if (voiceOpenBtn) {
  voiceOpenBtn.addEventListener("click", () => {
    openVoiceWindow().catch((e) => setStatus((e && e.message) || I18n.t("errUnknown"), "error"));
  });
}

if (imageOpenBtn) {
  imageOpenBtn.addEventListener("click", () => {
    openImageWindow().catch((e) => setStatus((e && e.message) || I18n.t("errUnknown"), "error"));
  });
}

function showBootError(msg) {
  const el = document.getElementById("boot-error");
  if (!el) return;
  el.style.display = "block";
  el.textContent = msg;
}

function isMobileUi() {
  // Never use popup width here: desktop Firefox popups are ~320px and would
  // be mis-detected as "mobile", which disabled Matrix rain and bloated layout.
  try {
    const ua = navigator.userAgent || "";
    if (/Android/i.test(ua)) return true;
    // Touch-primary devices without fine pointer / hover (phones, many tablets)
    if (
      window.matchMedia &&
      window.matchMedia("(pointer: coarse)").matches &&
      window.matchMedia("(hover: none)").matches
    ) {
      return true;
    }
  } catch (_e) {}
  return false;
}

async function bootPopup() {
  try {
    // Matrix rain is heavy and can look like a blank black page on phones.
    if (isMobileUi()) {
      document.body.classList.add("no-matrix");
    } else {
      initMatrixBackground();
    }

    if (typeof I18n !== "undefined" && I18n.init) {
      await I18n.init();
    }
    await loadSettings();
    if (typeof I18n !== "undefined") {
      await applyTranslations();
    }

    const versionEl = document.getElementById("version");
    if (versionEl && browser.runtime && browser.runtime.getManifest) {
      versionEl.textContent = `v${browser.runtime.getManifest().version}`;
    }

    setTimeout(resizeMatrixCanvas, 80);
  } catch (err) {
    const msg = (err && err.message) || String(err);
    console.error("Enigma popup boot failed", err);
    showBootError("UI-Startfehler: " + msg);
  }
}

bootPopup().catch((err) => {
  showBootError("UI-Startfehler: " + ((err && err.message) || String(err)));
});
