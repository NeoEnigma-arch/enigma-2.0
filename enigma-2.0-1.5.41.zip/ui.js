/* Enigma mobile / options UI – root page (ui.html). Keep resilient for Firefox Android. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const passwordInput = $("password");
  const rememberInput = $("remember");
  const autoDecryptInput = $("auto-decrypt");
  const cipherFormatSelect = $("cipher-format");
  const statusEl = $("status");
  const bannerEl = $("banner");
  const cipherInput = $("cipher-input");
  const cipherResult = $("cipher-result");

  const CIPHER_FORMATS = ["katakana", "runes", "braille", "zalgo", "mixed"];
  const DEFAULT_CIPHER_FORMAT = "katakana";

  function showBanner(msg, ok) {
    if (!bannerEl) return;
    bannerEl.textContent = msg;
    bannerEl.className = "banner show" + (ok ? " ok" : "");
  }

  function setStatus(msg, type) {
    if (!statusEl) return;
    statusEl.textContent = msg || "";
    statusEl.className = "status" + (type === "ok" ? " ok" : type === "error" || type === "err" ? " err" : "");
  }

  /** Password only in storage.session – never storage.local. */
  async function sessionPasswordGet() {
    try {
      if (browser.storage && browser.storage.session) {
        return await browser.storage.session.get(["password", "remember"]);
      }
    } catch (_e) {}
    return {};
  }

  async function saveSessionPassword() {
    const password = (passwordInput && passwordInput.value.trim()) || "";
    const remember = Boolean(rememberInput && rememberInput.checked);

    try {
      if (browser.storage && browser.storage.session) {
        if (remember && password) {
          await browser.storage.session.set({ password, remember: true });
        } else {
          await browser.storage.session.remove(["password", "remember"]);
        }
        return;
      }
    } catch (_e) {}

    try {
      await browser.runtime.sendMessage({
        type: "set-session-password",
        password: remember ? password : "",
        remember
      });
    } catch (_e2) {}
  }

  async function loadSettings() {
    let sessionData = {};
    let localData = {};
    try {
      browser.storage.local.remove("password").catch(() => {});
      [sessionData, localData] = await Promise.all([
        sessionPasswordGet(),
        browser.storage.local.get(["autoDecrypt", "cipherFormat"])
      ]);
    } catch (e) {
      showBanner("Einstellungen konnten nicht geladen werden: " + (e.message || e));
      return;
    }

    if (passwordInput && sessionData.password) passwordInput.value = sessionData.password;
    if (rememberInput) rememberInput.checked = Boolean(sessionData.remember);
    if (autoDecryptInput) autoDecryptInput.checked = Boolean(localData.autoDecrypt);
    if (cipherFormatSelect) {
      const fmt = localData.cipherFormat || DEFAULT_CIPHER_FORMAT;
      cipherFormatSelect.value = CIPHER_FORMATS.includes(fmt) ? fmt : DEFAULT_CIPHER_FORMAT;
    }
    // Drop legacy user color setting (colors are fixed per format now)
    browser.storage.local.remove("matrixColor").catch(() => {});
  }

  async function getActiveTab() {
    try {
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs[0]) return tabs[0];
    } catch (_e) {}
    try {
      const tabs = await browser.tabs.query({ active: true });
      return (tabs || []).find((t) => t.url && !t.url.startsWith("moz-extension:")) || tabs[0];
    } catch (_e2) {
      return null;
    }
  }

  async function runAction(action) {
    const password = (passwordInput && passwordInput.value.trim()) || "";
    if (!password) {
      setStatus("Bitte Passwort eingeben.", "error");
      return;
    }

    setStatus("Arbeitet…");

    const tab = await getActiveTab();
    if (!tab || tab.id == null) {
      setStatus("Kein aktiver Web-Tab. Öffne z. B. x.com und versuche es erneut.", "error");
      return;
    }
    if (tab.url && (tab.url.startsWith("moz-extension:") || tab.url.startsWith("about:"))) {
      setStatus("Wechsle zuerst zu einer normalen Webseite (nicht Enigma-Tab).", "error");
      return;
    }

    try {
      const response = await browser.runtime.sendMessage({
        type: "run-content-action",
        action,
        password,
        remember: Boolean(rememberInput && rememberInput.checked),
        tabId: tab.id
      });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "Aktion fehlgeschlagen");
      }
      const n = response.count != null ? response.count : "?";
      setStatus("Fertig (" + n + ").", "ok");
    } catch (error) {
      const msg = (error && error.message) || String(error);
      if (msg.indexOf("Receiving end") !== -1 || msg.indexOf("Could not establish") !== -1 || msg.indexOf("Content Script") !== -1) {
        setStatus("Content-Script fehlt. Seite neu laden, dann erneut versuchen.", "error");
      } else {
        setStatus(msg, "error");
      }
    }
  }

  async function decryptCipherNow() {
    const password = (passwordInput && passwordInput.value.trim()) || "";
    let cipher = (cipherInput && cipherInput.value.trim()) || "";

    if (cipher.indexOf("#c=") !== -1) {
      try {
        const i = cipher.indexOf("#c=");
        cipher = decodeURIComponent(cipher.slice(i + 3));
      } catch (_e) {}
    }
    cipher = cipher.replace(/^web\+enigma:\/*/i, "").trim();

    if (!password) {
      setStatus("Bitte Passwort eingeben.", "error");
      return;
    }
    if (!cipher) {
      setStatus("Bitte Cipher einfügen.", "error");
      return;
    }

    await saveSessionPassword();
    setStatus("Entschlüssele…");
    try {
      const response = await browser.runtime.sendMessage({
        type: "crypto-decrypt",
        ciphertext: cipher,
        password
      });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "decrypt failed");
      }
      if (cipherResult) cipherResult.value = response.plaintext;
      setStatus("Entschlüsselt.", "ok");
    } catch (_e) {
      if (cipherResult) cipherResult.value = "";
      setStatus("Entschlüsselung fehlgeschlagen (Passwort/Format?).", "error");
    }
  }

  async function openExtensionPage(page, size, okMsg) {
    await saveSessionPassword();
    const url = browser.runtime.getURL(page);
    const width = (size && size.width) || 400;
    const height = (size && size.height) || 560;
    try {
      if (browser.windows && typeof browser.windows.create === "function") {
        await browser.windows.create({ url, type: "popup", width, height });
        setStatus(okMsg, "ok");
        return;
      }
    } catch (_e) {}
    try {
      await browser.tabs.create({ url });
      setStatus(okMsg, "ok");
    } catch (err) {
      setStatus((err && err.message) || "Fenster konnte nicht geöffnet werden.", "error");
    }
  }

  async function openVoice() {
    await openExtensionPage("voice-window.html", { width: 400, height: 620 }, "Voice-Fenster geöffnet.");
  }

  async function openImage() {
    const password = (passwordInput && passwordInput.value.trim()) || "";
    if (!password) {
      setStatus("Bitte Passwort eingeben.", "error");
      return;
    }
    await openExtensionPage("image-window.html", { width: 400, height: 560 }, "Bild-Fenster geöffnet.");
  }

  function wire() {
    const map = {
      "encrypt-selection": "encrypt-selection",
      "decrypt-selection": "decrypt-selection",
      "encrypt-page": "encrypt-page",
      "decrypt-page": "decrypt-page"
    };
    Object.keys(map).forEach((id) => {
      const el = $(id);
      if (el) el.addEventListener("click", () => runAction(map[id]));
    });

    if (passwordInput) passwordInput.addEventListener("input", () => saveSessionPassword().catch(() => {}));
    if (rememberInput) rememberInput.addEventListener("change", () => saveSessionPassword().catch(() => {}));

    if (autoDecryptInput) {
      autoDecryptInput.addEventListener("change", async () => {
        if (autoDecryptInput.checked) {
          const password = (passwordInput && passwordInput.value.trim()) || "";
          if (!password) {
            autoDecryptInput.checked = false;
            setStatus("Zuerst Passwort eingeben.", "error");
            return;
          }
          if (rememberInput) rememberInput.checked = true;
          await saveSessionPassword();
        }
        await browser.storage.local.set({ autoDecrypt: autoDecryptInput.checked });
        setStatus(autoDecryptInput.checked ? "Auto-Decrypt an." : "Auto-Decrypt aus.", "ok");
      });
    }

    if (cipherFormatSelect) {
      cipherFormatSelect.addEventListener("change", async () => {
        const v = cipherFormatSelect.value;
        const format = CIPHER_FORMATS.includes(v) ? v : DEFAULT_CIPHER_FORMAT;
        await browser.storage.local.set({ cipherFormat: format });
        setStatus("Format gespeichert.", "ok");
      });
    }

    const decBtn = $("decrypt-cipher");
    if (decBtn) decBtn.addEventListener("click", () => decryptCipherNow().catch((e) => setStatus(e.message, "error")));

    const voiceBtn = $("voice-open");
    if (voiceBtn) voiceBtn.addEventListener("click", () => openVoice().catch((e) => setStatus(e.message, "error")));

    const imageBtn = $("image-open");
    if (imageBtn) imageBtn.addEventListener("click", () => openImage().catch((e) => setStatus(e.message, "error")));
  }

  async function boot() {
    try {
      if (typeof browser === "undefined") {
        showBanner("browser API fehlt – Seite muss als Firefox-Extension geöffnet werden.");
        return;
      }

      try {
        const ver = browser.runtime.getManifest().version;
        const vEl = $("version");
        if (vEl) vEl.textContent = "v" + ver + " · ui.html";
      } catch (_e) {}

      await loadSettings();
      wire();
      showBanner("Enigma UI geladen. Passwort setzen und Aktionen nutzen.", true);
      setTimeout(() => {
        if (bannerEl && bannerEl.classList.contains("ok")) {
          bannerEl.classList.remove("show");
        }
      }, 2500);
    } catch (err) {
      showBanner("Startfehler: " + ((err && err.message) || String(err)));
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => boot());
  } else {
    boot();
  }
})();
