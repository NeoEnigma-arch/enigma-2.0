(function () {
  "use strict";

  const passwordEl = document.getElementById("password");
  const statusEl = document.getElementById("status");
  const fileLabel = document.getElementById("file-label");
  const preview = document.getElementById("preview");
  const previewEmpty = document.getElementById("preview-empty");
  const btnEncrypt = document.getElementById("btn-pick-encrypt");
  const btnDecrypt = document.getElementById("btn-pick-decrypt");
  const fileEncrypt = document.getElementById("file-encrypt");
  const fileDecrypt = document.getElementById("file-decrypt");

  function tr(key, ...args) {
    if (typeof I18n !== "undefined" && typeof I18n.t === "function") {
      const msg = I18n.t(key, ...args);
      if (msg && msg !== key) return msg;
    }
    return key;
  }

  function setStatus(msg, type) {
    if (!statusEl) return;
    statusEl.textContent = msg || "";
    statusEl.className =
      "status" + (type === "ok" ? " ok" : type === "err" || type === "error" ? " err" : "");
  }

  function applyLanguage() {
    if (typeof I18n === "undefined") return;
    I18n.applyToDocument();
    const title = tr("imageWindowTitle");
    if (title && title !== "imageWindowTitle") {
      document.title = title;
    }
  }

  function showPreview(blob) {
    if (!preview) return;
    const url = URL.createObjectURL(blob);
    preview.onload = () => {
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    };
    preview.src = url;
    preview.hidden = false;
    if (previewEmpty) previewEmpty.hidden = true;
  }

  async function loadSavedPassword() {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.session) {
        const data = await browser.storage.session.get("password");
        if (data && data.password && passwordEl) {
          passwordEl.value = data.password;
        }
      }
    } catch (_e) {}
  }

  async function persistPassword(password) {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.session) {
        await browser.storage.session.set({ password, remember: true });
      }
    } catch (_e) {}
  }

  function getPassword() {
    return (passwordEl && passwordEl.value.trim()) || "";
  }

  async function runEncrypt(file) {
    if (!file) return;
    const password = getPassword();
    if (!password) {
      setStatus(tr("statusImagePasswordFirst"), "err");
      return;
    }
    if (typeof ImageScramble === "undefined") {
      setStatus(tr("statusImageModuleMissing"), "err");
      return;
    }

    setStatus(tr("statusImageScrambling"));
    if (btnEncrypt) btnEncrypt.disabled = true;
    if (btnDecrypt) btnDecrypt.disabled = true;
    if (fileLabel) fileLabel.textContent = file.name || "";

    try {
      await persistPassword(password);
      const result = await ImageScramble.scrambleAndDownload(file, password);
      showPreview(result.blob);
      setStatus(
        tr(
          "statusImageSaved",
          result.filename,
          String(result.width),
          String(result.height)
        ),
        "ok"
      );
    } catch (err) {
      setStatus((err && err.message) || String(err), "err");
    } finally {
      if (btnEncrypt) btnEncrypt.disabled = false;
      if (btnDecrypt) btnDecrypt.disabled = false;
    }
  }

  async function runDecrypt(file) {
    if (!file) return;
    const password = getPassword();
    if (!password) {
      setStatus(tr("statusImagePasswordFirst"), "err");
      return;
    }
    if (typeof ImageScramble === "undefined") {
      setStatus(tr("statusImageModuleMissing"), "err");
      return;
    }

    setStatus(tr("statusImageDecrypting"));
    if (btnEncrypt) btnEncrypt.disabled = true;
    if (btnDecrypt) btnDecrypt.disabled = true;
    if (fileLabel) fileLabel.textContent = file.name || "";

    try {
      await persistPassword(password);
      const result = await ImageScramble.unscrambleAndDownload(file, password);
      showPreview(result.blob);
      setStatus(tr("statusImageRestored", result.filename), "ok");
    } catch (err) {
      setStatus((err && err.message) || String(err), "err");
    } finally {
      if (btnEncrypt) btnEncrypt.disabled = false;
      if (btnDecrypt) btnDecrypt.disabled = false;
    }
  }

  function wireButtons() {
    if (btnEncrypt && fileEncrypt) {
      btnEncrypt.addEventListener("click", () => {
        if (!getPassword()) {
          setStatus(tr("statusImagePasswordFirst"), "err");
          if (passwordEl) passwordEl.focus();
          return;
        }
        fileEncrypt.value = "";
        fileEncrypt.click();
      });
      fileEncrypt.addEventListener("change", () => {
        const file = fileEncrypt.files && fileEncrypt.files[0];
        runEncrypt(file).catch((e) => setStatus((e && e.message) || String(e), "err"));
      });
    }

    if (btnDecrypt && fileDecrypt) {
      btnDecrypt.addEventListener("click", () => {
        if (!getPassword()) {
          setStatus(tr("statusImagePasswordFirst"), "err");
          if (passwordEl) passwordEl.focus();
          return;
        }
        fileDecrypt.value = "";
        fileDecrypt.click();
      });
      fileDecrypt.addEventListener("change", () => {
        const file = fileDecrypt.files && fileDecrypt.files[0];
        runDecrypt(file).catch((e) => setStatus((e && e.message) || String(e), "err"));
      });
    }
  }

  async function boot() {
    try {
      if (typeof I18n !== "undefined" && I18n.init) {
        await I18n.init();
        applyLanguage();
      }
    } catch (_e) {}

    await loadSavedPassword();
    wireButtons();

    // Live update if language is changed in the popup while this window is open
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.onChanged) {
        browser.storage.onChanged.addListener((changes, area) => {
          if (area !== "local") return;
          const key = typeof I18n !== "undefined" ? I18n.STORAGE_KEY : "uiLocale";
          if (!changes[key]) return;
          const next = changes[key].newValue || "";
          Promise.resolve()
            .then(async () => {
              if (typeof I18n === "undefined") return;
              if (!next || next === "auto") {
                await I18n.setLocale("auto", { persist: false });
              } else {
                await I18n.setLocale(next, { persist: false });
              }
              applyLanguage();
            })
            .catch(() => {});
        });
      }
    } catch (_e) {}
  }

  boot().catch(() => {});
})();
