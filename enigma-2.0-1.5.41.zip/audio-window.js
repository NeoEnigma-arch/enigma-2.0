(function () {
  const STORAGE_KEY = "audioWindowText";

  const textEl = document.getElementById("text");
  const statusEl = document.getElementById("status");
  const metaEl = document.getElementById("meta");
  const playBtn = document.getElementById("play");
  const stopBtn = document.getElementById("stop");
  const downloadBtn = document.getElementById("download");
  const copyBtn = document.getElementById("copy");
  const speedSelect = document.getElementById("speed");
  const waveCanvas = document.getElementById("wave");

  let sourceText = "";
  let modemText = "";
  let wavBlob = null;
  let durationSec = 0;
  let currentBaud = 50;
  let audioCtx = null;
  let playingSource = null;
  let animId = null;

  function setStatus(msg, isError) {
    if (!statusEl) return;
    statusEl.textContent = msg || "";
    statusEl.className = isError ? "status error" : "status";
  }

  function getTextFromUrl() {
    try {
      const hash = window.location.hash || "";
      if (hash.startsWith("#t=")) {
        return decodeURIComponent(hash.slice(3));
      }
    } catch (_e) {}
    return "";
  }

  async function loadText() {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.session) {
        const data = await browser.storage.session.get(STORAGE_KEY);
        if (data && data[STORAGE_KEY]) {
          const text = data[STORAGE_KEY];
          await browser.storage.session.remove(STORAGE_KEY).catch(() => {});
          return text;
        }
      }
    } catch (_e) {}
    return getTextFromUrl();
  }

  /** Prefer compact ENC:v1 for shorter/more reliable modem audio. */
  function compactForModem(text) {
    const trimmed = (text || "").trim();
    if (!trimmed) return "";

    if (trimmed.startsWith("ENC:v1:")) {
      return trimmed;
    }

    if (typeof TextCrypto !== "undefined" && TextCrypto.isEncrypted && TextCrypto.getPayloadBase64) {
      try {
        let cipher = trimmed;
        if (TextCrypto.findTokens) {
          const tokens = TextCrypto.findTokens(trimmed);
          if (tokens.length > 0) cipher = tokens[0].cipher;
        }
        if (TextCrypto.isEncrypted(cipher)) {
          const b64 = TextCrypto.getPayloadBase64(cipher);
          if (b64 && b64.length >= 8) {
            return "ENC:v1:" + b64;
          }
        }
      } catch (_e) {}
    }

    return trimmed;
  }

  function drawWavePreview(samples) {
    if (!waveCanvas) return;
    const ctx = waveCanvas.getContext("2d");
    const w = waveCanvas.width;
    const h = waveCanvas.height;
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, w, h);
    if (!samples || !samples.length) return;

    ctx.strokeStyle = "#00ff41";
    ctx.lineWidth = 1;
    ctx.beginPath();
    const step = Math.max(1, Math.floor(samples.length / w));
    const mid = h / 2;
    for (let x = 0; x < w; x++) {
      const i = x * step;
      const y = mid - (samples[i] || 0) * (mid - 4);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  function currentSpeed() {
    return (speedSelect && speedSelect.value) || "robust";
  }

  function buildAudio() {
    if (typeof EnigmaModem === "undefined") {
      throw new Error("Modem module missing.");
    }
    modemText = compactForModem(sourceText);
    if (!modemText) {
      throw new Error("No text to encode.");
    }
    const opts = { speed: currentSpeed() };
    const encoded = EnigmaModem.encodeToWavBlob(modemText, opts);
    wavBlob = encoded.blob;
    durationSec = encoded.durationSec;
    currentBaud = encoded.baud || EnigmaModem.BAUD;
    const { samples } = EnigmaModem.encodeToSamples(modemText, opts);
    drawWavePreview(samples);
    if (metaEl) {
      metaEl.textContent =
        "Duration ~" +
        durationSec.toFixed(1) +
        "s · acoustic · " +
        currentBaud +
        " baud · " +
        modemText.length +
        " chars payload";
    }
  }

  async function play() {
    if (!wavBlob) {
      setStatus("No audio built.", true);
      return;
    }
    stop();
    try {
      const buf = await wavBlob.arrayBuffer();
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const audioBuffer = await audioCtx.decodeAudioData(buf.slice(0));
      playingSource = audioCtx.createBufferSource();
      playingSource.buffer = audioBuffer;
      playingSource.connect(audioCtx.destination);
      playingSource.onended = () => {
        setStatus("Playback finished.");
        playingSource = null;
      };
      playingSource.start(0);
      setStatus("Playing modem tones…");
    } catch (e) {
      setStatus((e && e.message) || "Playback failed.", true);
    }
  }

  function stop() {
    try {
      if (playingSource) {
        playingSource.stop();
        playingSource.disconnect();
      }
    } catch (_e) {}
    playingSource = null;
    if (audioCtx) {
      try {
        audioCtx.close();
      } catch (_e) {}
      audioCtx = null;
    }
  }

  function download() {
    if (!wavBlob) {
      setStatus("No audio to download.", true);
      return;
    }
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "enigma-modem.wav";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    setStatus("WAV download started.");
  }

  async function copyCipher() {
    const t = sourceText || modemText;
    try {
      await navigator.clipboard.writeText(t);
      setStatus("Cipher copied.");
    } catch (_e) {
      if (textEl) {
        textEl.select();
        document.execCommand("copy");
        setStatus("Cipher copied.");
      }
    }
  }

  async function init() {
    sourceText = (await loadText()).trim();
    if (textEl) textEl.value = sourceText;

    if (!sourceText) {
      setStatus("No cipher text. Select encrypted text and use the context menu.", true);
      playBtn.disabled = true;
      downloadBtn.disabled = true;
      return;
    }

    try {
      buildAudio();
      setStatus("Ready – play or download WAV.");
    } catch (e) {
      setStatus((e && e.message) || "Encode failed.", true);
      playBtn.disabled = true;
      downloadBtn.disabled = true;
    }
  }

  playBtn.addEventListener("click", play);
  stopBtn.addEventListener("click", () => {
    stop();
    setStatus("Stopped.");
  });
  downloadBtn.addEventListener("click", download);
  copyBtn.addEventListener("click", copyCipher);
  function rebuildFromUi() {
    stop();
    try {
      buildAudio();
      setStatus(
        "Rebuilt (acoustic, " +
          currentBaud +
          " baud, ~" +
          durationSec.toFixed(1) +
          "s). Play or download."
      );
    } catch (e) {
      setStatus((e && e.message) || "Rebuild failed.", true);
    }
  }

  if (speedSelect) {
    speedSelect.addEventListener("change", rebuildFromUi);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
