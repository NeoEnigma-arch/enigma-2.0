(function () {
  const STORAGE_KEY = "textWindowText";

  function getTextFromUrl() {
    try {
      const hash = window.location.hash || "";
      if (hash.startsWith("#t=")) {
        return decodeURIComponent(hash.slice(3));
      }
    } catch (_) {}
    try {
      return new URLSearchParams(window.location.search).get("text") || "";
    } catch (_) {
      return "";
    }
  }

  async function loadText() {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.session) {
        const data = await browser.storage.session.get(STORAGE_KEY);
        if (data && data[STORAGE_KEY]) {
          const text = data[STORAGE_KEY];
          await browser.storage.session.remove(STORAGE_KEY).catch(() => {});
          return text;
        }
      }
    } catch (_) {}
    return getTextFromUrl();
  }

  async function init() {
    const text = (await loadText()).trim();
    const textarea = document.getElementById("text");
    const copyBtn = document.getElementById("copy");

    if (textarea) {
      textarea.value = text;
      setTimeout(() => {
        try {
          textarea.select();
        } catch (_) {}
      }, 40);
    }

    if (text && navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
    }

    if (copyBtn) {
      copyBtn.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(text);
          const original = copyBtn.textContent;
          copyBtn.textContent = "Kopiert!";
          copyBtn.disabled = true;
          setTimeout(() => {
            copyBtn.textContent = original;
            copyBtn.disabled = false;
          }, 1400);
        } catch (_) {
          if (textarea) {
            textarea.select();
            document.execCommand("copy");
          }
        }
      });
    }

    if (textarea) {
      textarea.addEventListener("click", () => {
        try {
          textarea.select();
        } catch (_) {}
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
