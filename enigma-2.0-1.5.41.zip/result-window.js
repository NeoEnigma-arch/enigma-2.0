(function () {
  const STORAGE_KEY = "resultWindowText";

  async function loadText() {
    try {
      if (typeof browser !== "undefined" && browser.storage?.session) {
        const data = await browser.storage.session.get(STORAGE_KEY);
        if (data && data[STORAGE_KEY]) {
          const text = data[STORAGE_KEY];
          await browser.storage.session.remove(STORAGE_KEY).catch(() => {});
          return text;
        }
      }
    } catch (_e) {}
    try {
      const hash = window.location.hash || "";
      if (hash.startsWith("#t=")) {
        return decodeURIComponent(hash.slice(3));
      }
    } catch (_e) {}
    return "";
  }

  async function init() {
    const textEl = document.getElementById("text");
    const statusEl = document.getElementById("status");
    const copyBtn = document.getElementById("copy");
    const text = (await loadText()) || "";

    if (textEl) {
      textEl.value = text;
      setTimeout(() => {
        try {
          textEl.focus();
          textEl.select();
        } catch (_e) {}
      }, 40);
    }

    if (text && navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
      if (statusEl) statusEl.textContent = "In Zwischenablage kopiert.";
    }

    if (copyBtn) {
      copyBtn.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(textEl ? textEl.value : text);
          if (statusEl) statusEl.textContent = "Kopiert.";
        } catch (_e) {
          if (textEl) {
            textEl.select();
            document.execCommand("copy");
            if (statusEl) statusEl.textContent = "Kopiert.";
          }
        }
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
