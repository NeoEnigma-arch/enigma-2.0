(function () {
  const RESULT_KEY = "resultWindowText";
  const MAX_SEC = 180; // 3 minutes – long acoustic robust tones

  const passwordEl = document.getElementById("password");
  const statusEl = document.getElementById("status");
  const cipherEl = document.getElementById("cipher");
  const plainEl = document.getElementById("plain");
  const btnLoad = document.getElementById("btn-load");
  const btnRecord = document.getElementById("btn-record");
  const btnStop = document.getElementById("btn-stop");
  const fileInput = document.getElementById("file");
  const banner = document.getElementById("rec-banner");
  const bannerText = document.getElementById("rec-banner-text");
  const levelWrap = document.getElementById("level-wrap");
  const levelFill = document.getElementById("level-fill");
  const micGainEl = document.getElementById("mic-gain");
  const micGainLabel = document.getElementById("mic-gain-label");

  let stream = null;
  let audioCtx = null;
  let processor = null;
  let chunks = [];
  let sampleRate = 44100;
  let capturing = false;
  let timerId = null;
  let seconds = 0;
  let peakLevel = 0;
  let micGain = 4;

  function getMicGain() {
    const v = micGainEl ? parseFloat(micGainEl.value) : micGain;
    if (!Number.isFinite(v) || v < 1) return 1;
    if (v > 20) return 20;
    return v;
  }

  function updateGainLabel() {
    micGain = getMicGain();
    if (micGainLabel) {
      const t = Number.isInteger(micGain) ? String(micGain) : micGain.toFixed(1);
      micGainLabel.textContent = "×" + t;
    }
  }

  async function loadMicGain() {
    try {
      if (browser.storage?.local) {
        const data = await browser.storage.local.get("voiceMicGain");
        if (data.voiceMicGain != null && micGainEl) {
          micGainEl.value = String(data.voiceMicGain);
        }
      }
    } catch (_e) {}
    updateGainLabel();
  }

  async function saveMicGain() {
    updateGainLabel();
    try {
      if (browser.storage?.local) {
        await browser.storage.local.set({ voiceMicGain: getMicGain() });
      }
    } catch (_e) {}
  }

  /** Soft-clip boosted sample to [-1, 1] without hard digital harshness. */
  function applyGainSample(x, gain) {
    const y = x * gain;
    if (y > 1) return 1 - 1 / (1 + (y - 1) * 2);
    if (y < -1) return -1 + 1 / (1 + (-1 - y) * 2);
    return y;
  }

  function setStatus(msg, type) {
    statusEl.textContent = msg || "";
    statusEl.className = "status" + (type ? " " + type : "");
  }

  async function loadSavedPassword() {
    try {
      if (typeof browser !== "undefined" && browser.storage?.session) {
        const data = await browser.storage.session.get("password");
        if (data.password) passwordEl.value = data.password;
      }
    } catch (_e) {}
  }

  async function openResultWindow(plaintext) {
    const text = String(plaintext || "");
    try {
      if (typeof browser !== "undefined" && browser.storage?.session) {
        await browser.storage.session.set({ [RESULT_KEY]: text });
      }
    } catch (_e) {}

    const base = typeof browser !== "undefined" && browser.runtime
      ? browser.runtime.getURL("result-window.html")
      : "result-window.html";
    let url = base;
    try {
      if (text.length <= 1600) {
        url += "#t=" + encodeURIComponent(text);
      }
    } catch (_e) {}

    try {
      if (browser.windows?.create) {
        await browser.windows.create({
          url,
          type: "popup",
          width: 380,
          height: 460,
          left: 100,
          top: 80
        });
        return;
      }
    } catch (_e) {}

    try {
      if (browser.tabs?.create) {
        await browser.tabs.create({ url });
        return;
      }
    } catch (_e) {}

    window.open(url, "enigma-result", "width=380,height=460");
  }

  async function finishWithCipher(cipherText) {
    cipherEl.value = cipherText || "";
    plainEl.value = "";

    if (!cipherText) {
      setStatus("Kein Cipher im Audio.", "error");
      return;
    }

    const password = (passwordEl.value || "").trim();
    if (!password) {
      setStatus("Cipher erkannt – bitte Passwort eingeben und WAV erneut laden / Aufnahme wiederholen.", "warn");
      return;
    }

    setStatus("Entschlüssele…");
    try {
      if (browser.storage?.session) {
        await browser.storage.session.set({ password, remember: true });
      }
    } catch (_e) {}

    try {
      const response = await browser.runtime.sendMessage({
        type: "crypto-decrypt",
        ciphertext: cipherText,
        password
      });
      if (!response || !response.ok) {
        throw new Error((response && response.error) || "decrypt failed");
      }
      const plain = response.plaintext;
      plainEl.value = plain;
      setStatus("Erfolg – Klartext-Fenster wird geöffnet…");
      await openResultWindow(plain);
      setStatus("Entschlüsselt. Klartext-Fenster geöffnet.");
    } catch (_e) {
      setStatus("Entschlüsselung fehlgeschlagen – Passwort prüfen.", "error");
    }
  }

  async function decodeBlob(blob) {
    if (typeof EnigmaModem === "undefined") {
      setStatus("Modem-Modul fehlt.", "error");
      return;
    }
    setStatus("Dekodiere Audio… (kann ein paar Sekunden dauern)");
    let decoded;
    try {
      decoded = await EnigmaModem.decodeFromBlob(blob);
    } catch (e) {
      setStatus("Audio konnte nicht gelesen werden: " + ((e && e.message) || e), "error");
      return;
    }
    if (!decoded.ok || !decoded.text) {
      setStatus(decoded.error || "Kein Enigma-Modem-Signal gefunden.", "error");
      return;
    }
    setStatus("Modem-Signal erkannt.");
    await finishWithCipher(decoded.text);
  }

  async function decodeSamples(samples, rate) {
    if (typeof EnigmaModem === "undefined") {
      setStatus("Modem-Modul fehlt.", "error");
      return;
    }
    setStatus("Dekodiere Aufnahme… (kurz warten)");
    let decoded;
    try {
      decoded = EnigmaModem.decodeFromSamplesAsync
        ? await EnigmaModem.decodeFromSamplesAsync(samples, rate)
        : EnigmaModem.decodeFromSamples(samples, rate);
    } catch (e) {
      setStatus("Dekodierung abgestürzt: " + ((e && e.message) || e), "error");
      return;
    }
    if (!decoded.ok || !decoded.text) {
      setStatus(decoded.error || "Kein Enigma-Modem-Signal gefunden.", "error");
      return;
    }
    setStatus("Modem-Signal erkannt.");
    await finishWithCipher(decoded.text);
  }

  function setRecordingUi(on) {
    capturing = on;
    banner.classList.toggle("active", on);
    if (levelWrap) {
      levelWrap.classList.toggle("active", on);
      levelWrap.style.display = "block";
    }
    const levelLabel = document.getElementById("level-label");
    if (levelLabel) {
      levelLabel.textContent = on
        ? "Mikrofon-Pegel (live, nach Verstärkung)"
        : "Mikrofon-Pegel (startet mit Aufnahme)";
    }
    btnRecord.disabled = on;
    btnStop.disabled = !on;
    btnLoad.disabled = on;
    if (!on && levelFill) {
      levelFill.style.width = "0%";
      levelFill.style.background = "#22c55e";
    }
  }

  function stopHardware() {
    try {
      if (processor) {
        processor.onaudioprocess = null;
        processor.disconnect();
      }
    } catch (_e) {}
    processor = null;
    try {
      if (audioCtx) audioCtx.close();
    } catch (_e) {}
    audioCtx = null;
    if (stream) stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }

  function mergeChunks(list) {
    let n = 0;
    for (const c of list) n += c.length;
    const out = new Float32Array(n);
    let o = 0;
    for (const c of list) {
      out.set(c, o);
      o += c.length;
    }
    return out;
  }

  async function startRecord() {
    if (capturing) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus("Mikrofon wird hier nicht unterstützt.", "error");
      return;
    }

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
          channelCount: 1
        }
      });
    } catch (_e) {
      setStatus("Mikrofon-Zugriff verweigert. Bitte erlauben und erneut versuchen.", "error");
      return;
    }

    chunks = [];
    peakLevel = 0;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === "suspended") {
      try {
        await audioCtx.resume();
      } catch (_e) {}
    }
    sampleRate = audioCtx.sampleRate;
    const source = audioCtx.createMediaStreamSource(stream);
    processor = audioCtx.createScriptProcessor(4096, 1, 1);
    processor.onaudioprocess = (ev) => {
      if (!capturing) return;
      const input = ev.inputBuffer.getChannelData(0);
      const gain = getMicGain();
      const boosted = new Float32Array(input.length);
      let peak = 0;
      for (let i = 0; i < input.length; i++) {
        const s = applyGainSample(input[i], gain);
        boosted[i] = s;
        const a = Math.abs(s);
        if (a > peak) peak = a;
      }
      chunks.push(boosted);
      peakLevel = peakLevel * 0.85 + peak * 0.15;
      if (levelFill) {
        levelFill.style.width = Math.min(100, Math.round(peakLevel * 100)) + "%";
        if (peakLevel > 0.92) {
          levelFill.style.background = "#ef4444";
        } else if (peakLevel > 0.5) {
          levelFill.style.background = "linear-gradient(90deg, #22c55e, #eab308, #ef4444)";
        } else {
          levelFill.style.background = "#22c55e";
        }
      }
    };
    source.connect(processor);
    const mute = audioCtx.createGain();
    mute.gain.value = 0;
    processor.connect(mute);
    mute.connect(audioCtx.destination);

    setRecordingUi(true);
    seconds = 0;
    const g = getMicGain();
    bannerText.textContent = "AUFNAHME AKTIV – 0s · Gain ×" + g;
    setStatus(
      "Aufnahme läuft (Gain ×" +
        g +
        "). Box-Lautsprecher → Mikro. Pegel sollte bei Tönen deutlich ausschlagen."
    );

    timerId = setInterval(() => {
      seconds += 1;
      const gainNow = getMicGain();
      bannerText.textContent =
        "AUFNAHME AKTIV – " +
        seconds +
        "s (max " +
        MAX_SEC +
        "s) · Gain ×" +
        gainNow;
      setStatus(
        "Aufnahme aktiv: " +
          seconds +
          "s · Gain ×" +
          gainNow +
          " – Modem-Töne abspielen…"
      );
      if (seconds >= MAX_SEC) stopRecord();
    }, 1000);
  }

  async function stopRecord() {
    if (!capturing && !stream) return;
    if (timerId) {
      clearInterval(timerId);
      timerId = null;
    }
    setRecordingUi(false);
    await new Promise((r) => setTimeout(r, 100));
    const samples = mergeChunks(chunks);
    const rate = sampleRate;
    stopHardware();
    chunks = [];

    if (!samples.length) {
      setStatus("Aufnahme leer – nichts aufgenommen.", "error");
      return;
    }

    // Rough energy check (samples already include gain)
    let energy = 0;
    const step = Math.max(1, Math.floor(samples.length / 2000));
    for (let i = 0; i < samples.length; i += step) {
      energy += Math.abs(samples[i]);
    }
    if (energy < 0.008) {
      setStatus(
        "Aufnahme zu leise. Verstärkung erhöhen (z. B. ×8–×12), Box lauter, Mikro näher – dann erneut.",
        "error"
      );
      return;
    }

    await decodeSamples(samples, rate);
  }

  btnLoad.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = "";
    if (!file) {
      setStatus("Keine Datei gewählt.", "warn");
      return;
    }
    setStatus("Datei: " + file.name + " (" + Math.round(file.size / 1024) + " KB)…");
    await decodeBlob(file);
  });

  btnRecord.addEventListener("click", () => {
    startRecord().catch((e) => setStatus((e && e.message) || "Aufnahme fehlgeschlagen.", "error"));
  });
  btnStop.addEventListener("click", () => {
    stopRecord().catch((e) => setStatus((e && e.message) || "Stop fehlgeschlagen.", "error"));
  });

  if (micGainEl) {
    micGainEl.addEventListener("input", () => {
      updateGainLabel();
    });
    micGainEl.addEventListener("change", () => {
      saveMicGain();
    });
  }

  Promise.all([loadSavedPassword(), loadMicGain()]).then(() => {
    if (typeof EnigmaModem === "undefined") {
      setStatus(
        "Fehler: Modem-Modul nicht geladen. Addon neu laden (about:debugging → Neu laden).",
        "error"
      );
      if (btnRecord) btnRecord.disabled = true;
      if (btnLoad) btnLoad.disabled = true;
      return;
    }
    setStatus(
      "Bereit: Gain einstellen (Mikro vor Box oft ×6–×12), Passwort, dann WAV laden oder aufnehmen."
    );
  });
})();
