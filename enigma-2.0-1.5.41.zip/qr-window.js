(function () {
  "use strict";

  const QR_STORAGE_KEY = "qrWindowText";

  // Last payload used for on-screen QR – re-rendered larger for PNG export / clipboard
  let lastQrPayload = "";

  function getQrApi() {
    return (
      (window.EnigmaQR && window.EnigmaQR.generateQRCodeToCanvas) ||
      window.generateQRCodeToCanvas
    );
  }

  /** Screen preview: sharp modules + quiet zone */
  function renderQrToCanvas(canvas, text, forExport) {
    const api = getQrApi();
    if (typeof api !== "function") {
      throw new Error("QR-Bibliothek nicht geladen.");
    }
    if (forExport) {
      // High resolution for phone camera (print/photo of PNG)
      return api(text, canvas, {
        size: 900,
        minCellSize: 10,
        quietZone: 4,
        ecLevel: "M"
      });
    }
    // Compact preview in the popup window
    return api(text, canvas, {
      size: 280,
      minCellSize: 4,
      quietZone: 4,
      ecLevel: "M"
    });
  }

  const PREFIX_V1 = "ENC:v1:";

  function setStatus(msg, isError) {
    const el = document.getElementById("status");
    if (!el) return;
    el.textContent = msg || "";
    el.className = isError ? "status error" : "status";
  }

  function paintBlank(label) {
    const canvas = document.getElementById("qr-canvas");
    if (!canvas) return;
    try {
      canvas.width = 260;
      canvas.height = 260;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#f3f4f6";
      ctx.fillRect(0, 0, 260, 260);
      ctx.fillStyle = "#6b7280";
      ctx.font = "12px system-ui,sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(label || "…", 130, 135);
    } catch (_) {}
  }

  /**
   * Emblem ciphers are huge in UTF-8. QR gets compact ASCII ENC:v1:…
   * which the addon can still decrypt. Textarea keeps original.
   * Supports Katakana / Runes / Braille / Zalgo via TextCrypto.
   */
  function compactForQr(text) {
    const trimmed = (text || "").trim();
    if (!trimmed) {
      return { ok: false, reason: "empty", text: "" };
    }

    if (trimmed.startsWith(PREFIX_V1)) {
      return { ok: true, compact: true, text: trimmed };
    }

    if (typeof TextCrypto !== "undefined" && TextCrypto.isEncrypted && TextCrypto.getPayloadBase64) {
      try {
        // Prefer first cipher token if selection has surrounding noise
        let cipher = trimmed;
        if (TextCrypto.findTokens) {
          const tokens = TextCrypto.findTokens(trimmed);
          if (tokens.length > 0) {
            cipher = tokens[0].cipher;
          }
        }
        if (TextCrypto.isEncrypted(cipher)) {
          const base64 = TextCrypto.getPayloadBase64(cipher);
          if (base64 && base64.length >= 8) {
            return { ok: true, compact: true, text: PREFIX_V1 + base64 };
          }
        }
      } catch (_e) {
        // not a known cipher – treat as plain text
      }
    }

    return { ok: true, compact: false, text: trimmed };
  }

  /**
   * Real https URL so phone/Firefox opens a page instead of running a Google search.
   * Cipher is only in the hash (#c=…) – usually not sent to the server.
   * Page: GitHub Pages privacy.html (dual-purpose: privacy + decrypt when #c= is set).
   */
  const DECRYPT_PAGE_URL = "https://neoenigma-arch.github.io/enigma-2.0/privacy.html";

  function buildDecryptLink(cipher) {
    return DECRYPT_PAGE_URL + "#c=" + encodeURIComponent(cipher);
  }

  function generateQr(displayText) {
    const canvas = document.getElementById("qr-canvas");
    if (!canvas) {
      setStatus("Canvas fehlt.", true);
      return false;
    }

    const prepared = compactForQr(displayText);
    if (!prepared.ok && prepared.reason === "empty") {
      setStatus("Kein Text.", true);
      paintBlank("kein Text");
      return false;
    }

    let cipher = prepared.ok ? prepared.text : displayText;
    const usedCompact = prepared.ok && prepared.compact;

    // Prefer compact form; if matrix couldn't convert, refuse huge unicode
    if (!usedCompact) {
      let utf8Guess = 0;
      for (const ch of cipher) {
        const c = ch.codePointAt(0);
        utf8Guess += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
      }
      if (utf8Guess > 800) {
        setStatus(
          "Verschlüsselter Text konnte nicht kompakt umgewandelt werden und ist zu groß für QR. Markiere nur den Cipher-Block.",
          true
        );
        paintBlank("zu groß");
        return false;
      }
    }

    // QR contains a link to the decrypt page (opens in Firefox/browser on phone)
    const qrText = buildDecryptLink(cipher);

    // Hard limit: QR max ~2953 bytes (type 40-L)
    const MAX_CHARS = 2000;
    if (qrText.length > MAX_CHARS) {
      setStatus(
        "Text zu lang für QR-Link (" + qrText.length + " Zeichen). Kürzeren Text markieren.",
        true
      );
      paintBlank("zu lang");
      return false;
    }

    try {
      const t0 = performance.now();
      const info = renderQrToCanvas(canvas, qrText, false);
      lastQrPayload = qrText;
      const ms = Math.round(performance.now() - t0);

      // Separate fields so Cipher / Original can be selected independently
      const cipherEl = document.getElementById("field-cipher");
      const originalEl = document.getElementById("field-original");
      if (cipherEl) cipherEl.value = cipher;
      if (originalEl) originalEl.value = displayText;

      setStatus(
        "QR bereit · scannbar (Rand + ECC M)" +
          (info && info.typeNumber != null ? " · Typ " + info.typeNumber : "") +
          (info && info.size ? " · " + info.size + "px" : "") +
          " · " + ms + " ms"
      );

      const hint = document.getElementById("hint");
      if (hint) {
        hint.innerHTML =
          "PNG-Download speichert eine <strong>große, scharfe</strong> Version mit weißem Rand (besser für die Kamera). " +
          "Scan öffnet die Entschlüsselungsseite. Cipher und Original sind einzeln markierbar.";
      }

      return true;
    } catch (err) {
      console.error("QR generation failed", err);
      lastQrPayload = "";
      const msg = (err && err.message) || String(err);
      setStatus("QR-Fehler: " + msg, true);
      paintBlank("Fehler");
      return false;
    }
  }

  async function loadText() {
    // 1) Session storage (preferred)
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.session) {
        const data = await browser.storage.session.get(QR_STORAGE_KEY);
        if (data && data[QR_STORAGE_KEY]) {
          const text = data[QR_STORAGE_KEY];
          await browser.storage.session.remove(QR_STORAGE_KEY).catch(() => {});
          return text;
        }
      }
    } catch (e) {
      console.warn("session storage read failed", e);
    }

    // 2) URL hash backup: #t=...
    try {
      const hash = window.location.hash || "";
      if (hash.startsWith("#t=")) {
        return decodeURIComponent(hash.slice(3));
      }
      const hashParams = new URLSearchParams(hash.startsWith("#") ? hash.slice(1) : hash);
      if (hashParams.get("t")) {
        return hashParams.get("t");
      }
    } catch (_) {}

    // 3) Query string backup: ?text=...
    try {
      const params = new URLSearchParams(window.location.search);
      return params.get("text") || "";
    } catch (_) {
      return "";
    }
  }

  function nextPaint() {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(resolve);
      });
    });
  }

  function flashCopyBtn(btn, okLabel) {
    if (!btn) return;
    const original = btn.textContent;
    btn.textContent = okLabel || "Kopiert!";
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = original;
      btn.disabled = false;
    }, 1400);
  }

  async function copyText(text, btn, statusMsg) {
    const value = (text || "").trim();
    if (!value) {
      setStatus("Nichts zum Kopieren.", true);
      return;
    }
    try {
      await navigator.clipboard.writeText(value);
      flashCopyBtn(btn);
      setStatus(statusMsg || "Kopiert.");
    } catch (_) {
      // Fallback: temporary selection on a helper field (do not select-all on user fields)
      try {
        const helper = document.createElement("textarea");
        helper.value = value;
        helper.setAttribute("readonly", "");
        helper.style.position = "fixed";
        helper.style.left = "-9999px";
        document.body.appendChild(helper);
        helper.select();
        document.execCommand("copy");
        document.body.removeChild(helper);
        flashCopyBtn(btn);
        setStatus(statusMsg || "Kopiert.");
      } catch (_e2) {
        setStatus("Kopieren fehlgeschlagen.", true);
      }
    }
  }

  function fieldValue(id) {
    const el = document.getElementById(id);
    return el ? el.value || "" : "";
  }

  function buildExportCanvas() {
    if (!lastQrPayload) {
      throw new Error("Kein QR geladen.");
    }
    const exportCanvas = document.createElement("canvas");
    const info = renderQrToCanvas(exportCanvas, lastQrPayload, true);
    return { exportCanvas, info };
  }

  async function copyImage(btn) {
    try {
      const { exportCanvas, info } = buildExportCanvas();
      const blob = await new Promise((resolve) =>
        exportCanvas.toBlob(resolve, "image/png")
      );
      if (!blob) throw new Error("no blob");
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      if (btn) {
        const original = btn.textContent;
        btn.textContent = "Kopiert!";
        setTimeout(() => {
          btn.textContent = original;
        }, 1400);
      }
      setStatus(
        "QR-Bild kopiert (" +
          (info && info.size ? info.size + "×" + info.size + " px" : "hochauflösend") +
          ")."
      );
    } catch (_) {
      setStatus("QR-Bild konnte nicht kopiert werden. Nutze PNG-Download.", true);
    }
  }

  function downloadImage() {
    try {
      const { exportCanvas, info } = buildExportCanvas();
      const link = document.createElement("a");
      link.download = "enigma-qr.png";
      // PNG is lossless – good for QR modules
      link.href = exportCanvas.toDataURL("image/png");
      link.click();
      setStatus(
        "PNG heruntergeladen (" +
          (info && info.size ? info.size + "×" + info.size + " px, Rand 4 Module" : "hochauflösend") +
          ") – gut mit der Handykamera scannbar."
      );
    } catch (err) {
      const msg = (err && err.message) || String(err);
      setStatus("Download fehlgeschlagen: " + msg, true);
    }
  }

  async function init() {
    paintBlank("lade…");
    setStatus("Lade Text …");

    const text = (await loadText()).trim();
    const cipherEl = document.getElementById("field-cipher");
    const originalEl = document.getElementById("field-original");
    const copyTextBtn = document.getElementById("copy-text");
    const copyImageBtn = document.getElementById("copy-image");
    const downloadBtn = document.getElementById("download");

    if (!text) {
      if (cipherEl) cipherEl.value = "";
      if (originalEl) originalEl.value = "";
      setStatus("Kein Text übergeben. Markiere Text und wähle „Als QR-Code anzeigen“.", true);
      paintBlank("kein Text");
      return;
    }

    if (originalEl) {
      originalEl.value = text;
    }

    // Let the browser paint "creating…" before heavy work (avoids frozen blank UI)
    setStatus("Erstelle QR-Code …");
    paintBlank("generiere…");
    await nextPaint();

    // Yield once more so status is visible even if generation is sync-heavy
    await new Promise((r) => setTimeout(r, 0));

    generateQr(text);

    // Do not auto-copy or select-all – user selects what they need

    if (copyTextBtn) {
      copyTextBtn.addEventListener("click", () =>
        copyText(fieldValue("field-cipher") || text, copyTextBtn, "Cipher kopiert.")
      );
    }

    document.querySelectorAll(".copy-mini[data-target]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-target");
        const labels = {
          "field-cipher": "Cipher kopiert.",
          "field-original": "Original kopiert."
        };
        copyText(fieldValue(id), btn, labels[id] || "Kopiert.");
      });
    });

    if (copyImageBtn) {
      copyImageBtn.addEventListener("click", () => copyImage(copyImageBtn));
    }
    if (downloadBtn) {
      downloadBtn.addEventListener("click", downloadImage);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
